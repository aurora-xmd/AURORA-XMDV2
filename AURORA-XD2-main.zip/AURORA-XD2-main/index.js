function _0x1dea() {
    const _0x1696de = ['https://files.catbox.moe/i4chee.png', 'dbXhN', 'sendMessage', 'OkVZa', 'selectedId', 'action', 'image/webp', 'DXjJm', 'fSCfq', 'kxsyg', '[ 🤖 ] Bot connected to WhatsApp 📲', 'EcLEC', 'floor', 'mBpTN', './lib/prefix', 'TZEuS', '7391448vlfUdD', '❤‍🔥', 'subject', 'sendButtonText', 'lKIoi', 'function *\\( *\\)', 'sESuR', 'kqSXv', '3rRHtHS', 'startsWith', 'TzMpS', 'Failed to log activity:', 'replace', 'gif', '5yehbKE', 'LyNMn', 'SLteN', 'ubmYQ', 'query', 'eyHUn', 'IiQtg', 'CTCcX', 'bKfHo', 'YuOqe', 'name', 'DhthM', 'HDpUc', 'ibDPb', 'command', '🧞‍♀️', '256789101112', 'xYhRS', 'PhhRz', 'sendImageAsSticker', 'Marked message from ', 'dKONv', 'izQQg', '🇵🇰', 'unlinkSync', 'EluUa', 'verifiedName', 'downloadAndSaveMediaMessage', 'extname', 'OdJnG', 'KmQSV', 'ryHTs', 'wa-sticker-formatter', '\x0aitem2.X-ABLabel:GitHub\x0aitem3.URL:https://github.com/', 'mnFXN', 'IhOpf', 'qKfln', ' channel(s).\x0a\x0a', 'IsHrM', 'HJFAs', 'LwPcX', 'find', 'CkTbJ', 'UYsnl', '10ihwRXg', 'PYtgn', 'isMe', 'hGCpf', 'xQmiN', '🏵️', 'groups', 'quoted', 'split', 'utf-8', 'HaBmy', 'bXddv', 'selectedButtonId', 'OLuvr', 'VkIjf', 'KlAch', 'KeTIt', 'server', 'extendedTextMessage', 'hHBBe', 'axios', 'OwnerName', 'gZtFA', 'international', 'gyTXm', 'input', 'toLowerCase', 'ccykM', ' 🔴 Please add your session to SESSION_ID env !!', 'apply', 'WbIdU', '299928jAdghg', '💡 Tip: Following these channels keeps your bot updated with the latest news and features.', 'QYmBi', 'LTQqo', '\x0a✅ *AURORA-XD is now back online!*\x0a> <@', 'FYyEU', 'wlVxg', 'IYGWx', 'getNumber', 'fXPiF', 'yTVOo', 'commands', 'xZJGI', 'https://mega.nz/file/', 'tngym', 'IHAdW', 'ssejX', '❌ Failed to send restart notification:', 'acGlD', 'dqqcr', 'qGNZg', 'hydratedFooterText', 'Baabl', 'DUFUM', 'SlstB', './lib/ban.json', 'nEkfd', 'readViewOnce', 'fromObject', 'stringify', 'SmpGB', 'Vrizr', '.js', 'CUSTOM_REACT_EMOJIS', 'uRLCA', 'dGAIi', 'msWTD', ' channel(s) for updates.\x0a', 'JMRRO', 'asDocument', 'sZeRa', 'contacts', 'zIaXT', 'relayMessage', 'dZSQe', 'aaxJA', 'FgiCo', 'isBuffer', '💁‍♂️', 'rCptO', 'document', 'oEJSP', 'GlKpo', 'Kgtbg', 'key', 'init', 'jNypH', 'nsPmH', '🤹‍♀️', '👩‍🦰', '🌨️', 'qquMX', 'abUiO', 'DOhQc', 'tYQXy', 'Delete Detected:', 'react', 'yNwsX', 'hydratedButtons', 'jBDlE', 'reactionMessage', 'stdout', 'fBazF', 'ykrzx', 'author', 'newsletterFollow', 'cMod', 'NRFJK', 'viewOnceMessage', 'rrDbm', 'toString', 'ZFwYu', 'statusCode', 'cache-temp', 'QNAVg', 'buttonsResponseMessage', 'notify', 'APhNQ', 'tOIab', 'AIivf', 'xqUNC', 'nwAIq', '❌ Failed to follow ', 'map', 'args', 'lcbrz', 'YqrOf', 'IsgdI', 'shell', 'THDGj', 'gger', 'MbRrw', 'slice', '0@s.whatsapp.net', 'LiUTH', 'rMBDg', 'stderr', 'fexaQ', 'MvIKb', 'YVnMs', 'sendText', 'cPhpA', 'vTWzm', 'CEdta', 'getName', 'oVAzL', 'UILkw', 'lurzQ', 'yfWTr', 'READ_MESSAGE', 'nXZVn', 'parseMention', 'nqDYs', 'zNteu', 'path', 'gTJfx', '120363420656466131@newsletter', 'cqmqd', 'set', '3329396ciUlnt', '\x0a\x0a🛠️ Change prefix with ', 'ekEyp', 'xkJYo', 'ijvNF', '[ ❌ ] Connection failed:', '👰‍♀', 'PnLwy', 'writeFile', 'HoSjJ', 'FkQsv', 'GyOai', 'concat', 'ZOkuE', 'CpPrM', '\x0a\x0a*👋🏻  Hᴇʟʟᴏ, Lucky XD Bᴏᴛ Cᴏɴɴᴇᴄᴛᴇᴅ!*\x0a\x0a📺 Yᴛ Tᴜᴛᴏʀɪᴀʟs:\x0ahttps://youtube.com/@luckytechhub-i9u\x0a\x0a🔤 *Pʀᴇғɪx:* ', 'ephemeralMessage', '🎗️', 'LiBYx', 'arElG', 'PSUiq', 'isAdmins', 'content-type', 'downloadMediaMessage', 'PRXkY', 'ebewR', 'EkZKc', 'rmYwP', 'pino', 'PVdvV', '\x0aitem1.X-ABLabel:Click here to chat\x0aitem2.EMAIL;type=INTERNET:', 'YRMya', 'base64', 'GcKBo', 'participants', 'messages.upsert', 'includes', 'file-type', 'hwICg', 'contextInfo', 'wBmsM', 'readMessages', 'WJuWL', 'BEGIN:VCARD\x0aVERSION:3.0\x0aN:', 'xzxNJ', 'IjtEm', 'command exited with code ', 'EcjwU', 'CUSTOM_REACT', 'MODE', 'sDqrM', '👨‍💻', '🙅‍♀️', '🥲,😂,👍🏻,🙂,😔', 'body', 'xhzjU', 'close', 'MaqTb', 'readFileSync', ' Contact', 'OITIR', 'JWZKV', 'BCNJn', 'YimHD', '0|1|2|4|3', 'status@broadcast', '@g.us', 'string', 'packname', '❤‍🩹', 'Message', 'text', 'kqCPw', 'QaWSB', 'VIMbO', 'SpHzQ', 'fromMe', 'readdirSync', 'BVhnX', 'remoteJid', 'AdnoF', 'viewOnceMessageV2', 'fAyoD', 'pattern', 'location', 'user', 'writeFileSync', '👩‍⚕️', 'OHYqe', '22zIsJCr', 'NRJoP', 'PNjYH', 'decodeJid', '2213264TFDOVj', 'qrcode-terminal', 'hydratedTemplate', 'reply', 'imageMessage', 'dvZds', 'wcsbo', 'aGgAg', 'qNKMw', 'htTIp', 'wBjrq', 'Swibm', 'group-participants.update', 'sendFile', 'GPjTT', 'pLJmD', 'application/pdf', 'participant', 'gkVuA', 'isCreator', 'UpjUQ', 'ezncx', 'ndjBZ', 'Jjewt', 'quotedMessage', 'yRMho', 'ggqHm', 'WtNVQ', 'QpMgf', 'MSSXR', 'promises', 'mimetype', 'IKxxz', 'oWFaC', 'isBotAdmins', 'iMLAt', 'EzXWC', 'KQhkQ', 'XqzDK', 'pushname', 'fromURL', 'Firefox', 'listen', 'pqiKl', 'aQvck', 'uICJL', '🙋‍♀️', './exif.js', 'ROXRU', 'while (true) {}', 'counter', 'ENAQa', 'audio', 'message', 'zraIf', 'WhatsApp', 'withoutContact', 'hGJgS', 'IYdHf', 'rHexC', 'MObSP', 'hydratedContentText', 'tTJfj', 'head', 'json', 'botNumber', 'uYzyl', 'data', '\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)', 'WwNUN', 'ljctx', 'sticker', 'botNumber2', '2901861WCXvVe', 'AUTO_STATUS_REPLY', '🕊️', './lib/activityTracker', '🧑‍⚕️', 'oXGor', 'OymOl', '\x0a🧩 *Pʟᴜɢɪɴs:* ', 'IWiac', 'ZXfSV', 'VaWlH', '[ 🧩 ] ', ';;;;\x0aitem4.X-ABLabel:Region\x0aEND:VCARD', '🧑‍🦰', 'cwNAJ', 'klubv', 'fluent-ffmpeg', 'kqSts', 'NqFdm', 'FTcWz', 'send5ButImg', 'suKbi', 'gjktm', 'setStatus', '❌ Failed: ', 'image', 'matchAll', 'oJaAS', 'PSldr', '8CXQHKK', 'lVsaV', 'tNYcP', 'HgXwK', 'TDnlQ', 'groupMetadata', 'iEBeJ', 'BqZja', 'iXRAP', 'QeQXK', '💇‍♀️', 'xzaeb', 'mPCQn', 'HZPVB', 'isOwner', 'WdlEy', './settings', 'lMXKs', 'VPwao', 'videoMessage', 'isGroup', '\x0aFN:', 'uJkPV', 'jELWv', 'bYdzC', 'KbjxQ', 'OmHLL', './malvin', 'sendTextWithMentions', 'format', 'forEach', 'length', 'ext', 'UsNEH', '🦹🏻‍♀️', 'join', 'now', 'chat', 'PKbAb', 'EDCwT', 'jrIfD', './data/restart_notify.json', '120363420656466131@newsletter', 'AoMuy', 'xmlns', 'cTZwE', '🇺🇬', ' Plugins installed successfully ✅', 'sendContact', 'Bfdeu', 'avsjb', 'oENDc', 'mFTMY', '🎙️', 'from', 'copyNForward', 'push', 'NWttL', './lib/malvin.html', 'ZJhBF', 'segGb', 'NIiml', 'msg', 'LiduZ', 'Cdatz', 'true', 'NkLZg', 'YHksr', 'email', 'xUiRG', 'trim', 'kTkvz', 'nnWGp', 'singleSelectReply', 'jKyvd', 'hteWd', 'alloc', 'xIZAi', './exif', './lib', 'pgptw', 'TDNKf', 'yoJVc', 'BVZQl', '✅ Successfully followed ', '/sessions/', 'WZZiS', 'listResponseMessage', 'swHIW', 'dKzal', 'AUTO_STATUS_MSG', 'kwLMr', 'CiAbO', 'icmDT', '120363420656466131@newsletter', 'Fasyv', 'FFTfW', 'kLrYB', 'bqVOY', 'senderNumber', 'UGoqc', 'mtype', 'unlink', 'SNVwc', 'asSticker', '/sessions/creds.json', '@broadcast', 'type', 'ZhufI', 'call', 'Provide me with a query to run Master!', 'giovn', 'JhwiD', 'sendFileUrl', 'groupAdmins', 'GXSET', 'silent', 'WdwrK', 'random', '💁‍♀️', 'fromBuffer', '🤷‍♀️', 'eeGOM', 'KlEZB', '🙆‍♀️', 'OWLMo', 'hhCsQ', './plugins/', 'sender', 'wLlmJ', 'jCNtX', '@s.whatsapp.net', 'get', '545083kakfPE', './lib/functions', 'error', 'alias', 'log', 'NxJIu', 'keys', 'upload', 'categories', ' channel(s)\x0a', 'AUTO_STATUS_REACT', 'eVyHD', 'parse', 'fBBXx', 'pushName', 'mtimeMs', 'fHarC', 'video/mp4', 'private', 'MzOaj', 'constructor', 'HXQPo', 'nWvOQ', 'selectedRowId', './data', 'SdczS', 'OWNER_NUMBER', '[ 🟢 ] Session downloaded ✅', 'rTxHG', 'ZKvWQ', 'RqfKf', 'caption', 'ikCOa', '🍄‍🟫', 'GIIch', 'ydSMn', 'HHOrn', 'chain', 'documentMessage', '256789101112', 'statSync', 'JYTxl', 'xTNVj', 'uksOo', 'isCmd', 'function', 'oKmLi', '[PLUGIN ERROR] ', 'tvHrZ', 'viewOnce', 'conversation', 'avWpO', 'kmRTr', 'WebMessageInfo', 'NyLMw', '[ 🟡 ] Installing Plugins', 'EfhxW', 'eEXPN', 'pJVkV', 'templateButtonReplyMessage', 'groupName', 'waUploadToServer', 'MfPqd', 'sendMedia', 'test', 'url', 'connection.update', 'status', 'tmpdir', '.bin', 'nsCGd', 'rlwlX', '374998sNwXLZ', 'AXCFL', 'tEBqf', 'uPxup', 'existsSync', 'EFhbo', 'PUoRJ', 'readdir', 'AUTO_REACT', 'HHPVb', '🤦‍♀️', 'getFile', '@whiskeysockets/baileys', 'mkdirSync', 'YMBew'];
    _0x1dea = function () {
        return _0x1696de;
    };
    return _0x1dea();
}
const _0x1d324b = _0x4fdc;
(function (_0x3aa06c, _0x5466a9) {
    const _0x5df1d8 = _0x4fdc,
        _0x448b26 = _0x3aa06c();
    while (!![]) {
        try {
            const _0x77a94a = parseInt(_0x5df1d8(0x262)) / 0x1 + -parseInt(_0x5df1d8(0x2aa)) / 0x2 * (parseInt(_0x5df1d8(0x2d1)) / 0x3) + parseInt(_0x5df1d8(0x177)) / 0x4 * (-parseInt(_0x5df1d8(0x2d7)) / 0x5) + parseInt(_0x5df1d8(0x322)) / 0x6 + -parseInt(_0x5df1d8(0x11a)) / 0x7 * (parseInt(_0x5df1d8(0x1dd)) / 0x8) + -parseInt(_0x5df1d8(0x1c0)) / 0x9 * (parseInt(_0x5df1d8(0x303)) / 0xa) + -parseInt(_0x5df1d8(0x173)) / 0xb * (-parseInt(_0x5df1d8(0x2c9)) / 0xc);
            if (_0x77a94a === _0x5466a9) break;
            else _0x448b26['push'](_0x448b26['shift']());
        } catch (_0x5a772f) {
            _0x448b26['push'](_0x448b26['shift']());
        }
    }
}(_0x1dea, 0x4656b));
const _0x1787eb = (function () {
    const _0xe4473e = _0x4fdc,
        _0x47ae48 = {
            'tEcBe': function (_0x48fc4a, _0x1969bb) {
                return _0x48fc4a(_0x1969bb);
            },
            'nEkfd': function (_0x198af4, _0x936ded) {
                return _0x198af4 !== _0x936ded;
            },
            'ZOkuE': _0xe4473e(0x27b),
            'OWLMo': _0xe4473e(0x12d)
        };
    let _0x5ce960 = !![];
    return function (_0x5c9a94, _0x287410) {
        const _0x5d24a0 = _0xe4473e;
        if (_0x47ae48[_0x5d24a0(0x33c)](_0x47ae48[_0x5d24a0(0x127)], _0x47ae48[_0x5d24a0(0x25a)])) {
            const _0x23693e = _0x5ce960 ? function () {
                const _0x4f56f8 = _0x5d24a0;
                if (_0x287410) {
                    const _0x51f86a = _0x287410[_0x4f56f8(0x320)](_0x5c9a94, arguments);
                    return _0x287410 = null, _0x51f86a;
                }
            } : function () {};
            return _0x5ce960 = ![], _0x23693e;
        } else _0x47ae48['tEcBe'](_0x5630a0, _0x4a8ac8[_0x5d24a0(0x372)]());
    };
}());

function _0x4fdc(_0x5ed321, _0x24fcd7) {
    const _0x2edb85 = _0x1dea();
    return _0x4fdc = function (_0x4a35dc, _0x1787eb) {
        _0x4a35dc = _0x4a35dc - 0x11a;
        let _0x1deac7 = _0x2edb85[_0x4a35dc];
        return _0x1deac7;
    }, _0x4fdc(_0x5ed321, _0x24fcd7);
}(function () {
    const _0x2c77c5 = _0x4fdc,
        _0x214907 = {
            'KeTIt': function (_0x4b1a42, _0x2159bd) {
                return _0x4b1a42 + _0x2159bd;
            },
            'BLTMt': _0x2c77c5(0x1bb),
            'SmpGB': function (_0x3bf88f, _0x590f26) {
                return _0x3bf88f(_0x590f26);
            },
            'hftMa': _0x2c77c5(0x359),
            'nGYNJ': _0x2c77c5(0x287),
            'tYQXy': _0x2c77c5(0x31c),
            'ryHTs': function (_0x2fb229, _0x32baf8) {
                return _0x2fb229 === _0x32baf8;
            },
            'bUtDJ': function (_0x5e65d4) {
                return _0x5e65d4();
            },
            'JWZKV': function (_0x25e1df, _0x4762c8, _0x22a26a) {
                return _0x25e1df(_0x4762c8, _0x22a26a);
            }
        };
    _0x214907[_0x2c77c5(0x157)](_0x1787eb, this, function () {
        const _0x3baa9b = _0x2c77c5,
            _0x11dd78 = {
                'YimHD': function (_0x346e0d, _0xd91d8e) {
                    const _0x542734 = _0x4fdc;
                    return _0x214907[_0x542734(0x313)](_0x346e0d, _0xd91d8e);
                },
                'Kgtbg': '[PLUGIN ERROR] '
            },
            _0x2a5f24 = new RegExp('function *\\( *\\)'),
            _0x9f18f0 = new RegExp(_0x214907['BLTMt'], 'i'),
            _0x28e2d8 = _0x214907[_0x3baa9b(0x340)](_0x4a35dc, _0x214907['hftMa']);
        if (!_0x2a5f24[_0x3baa9b(0x2a2)](_0x28e2d8 + _0x214907['nGYNJ']) || !_0x9f18f0[_0x3baa9b(0x2a2)](_0x214907[_0x3baa9b(0x313)](_0x28e2d8, _0x214907[_0x3baa9b(0x362)]))) _0x28e2d8('0');
        else {
            if (_0x214907[_0x3baa9b(0x2f6)](_0x3baa9b(0x1a3), 'AicfZ')) {
                const _0x225944 = _0x3cc31a[_0x3baa9b(0x32d)]['find'](_0x55af8d => _0x55af8d[_0x3baa9b(0x16d)] === _0x286b74) || _0x293f51[_0x3baa9b(0x32d)][_0x3baa9b(0x300)](_0xaa9ca7 => _0xaa9ca7[_0x3baa9b(0x265)] && _0xaa9ca7[_0x3baa9b(0x265)][_0x3baa9b(0x13e)](_0x4ae7b9));
                if (_0x225944) {
                    if (_0x225944['react']) _0x878fb8[_0x3baa9b(0x2bb)](_0x2dc41c, {
                        'react': {
                            'text': _0x225944[_0x3baa9b(0x364)],
                            'key': _0x300ce6[_0x3baa9b(0x358)]
                        }
                    });
                    try {
                        const _0x1355a7 = {};
                        _0x1355a7[_0x3baa9b(0x213)] = _0x2a1cdd, _0x1355a7['quoted'] = _0x44c08d, _0x1355a7[_0x3baa9b(0x150)] = _0x266445, _0x1355a7['isCmd'] = _0x20da22, _0x1355a7[_0x3baa9b(0x2e5)] = _0x23450f, _0x1355a7['args'] = _0x325653, _0x1355a7['q'] = _0x495b49, _0x1355a7[_0x3baa9b(0x161)] = _0x3d0cda, _0x1355a7[_0x3baa9b(0x1f1)] = _0x1c640b, _0x1355a7[_0x3baa9b(0x25d)] = _0x36d5db, _0x1355a7[_0x3baa9b(0x240)] = _0x4a0b1d, _0x1355a7[_0x3baa9b(0x1bf)] = _0x2b9b86, _0x1355a7['botNumber'] = _0x4d712a, _0x1355a7[_0x3baa9b(0x19e)] = _0x173886, _0x1355a7['isMe'] = _0x4b17df, _0x1355a7['isOwner'] = _0x1d17f0, _0x1355a7[_0x3baa9b(0x18a)] = _0x247def, _0x1355a7['groupMetadata'] = _0x1a030f, _0x1355a7[_0x3baa9b(0x29e)] = _0x4eb7e9, _0x1355a7[_0x3baa9b(0x13c)] = _0x49d0b5, _0x1355a7['groupAdmins'] = _0x23c1a3, _0x1355a7[_0x3baa9b(0x199)] = _0x54a622, _0x1355a7[_0x3baa9b(0x12f)] = _0x1b51dd, _0x1355a7[_0x3baa9b(0x17a)] = _0x258aa3, _0x225944['function'](_0xbcf514, _0x3f7239, _0x5efbdb, _0x1355a7);
                    } catch (_0x4845f5) {
                        _0x15b01e[_0x3baa9b(0x264)](_0x11dd78[_0x3baa9b(0x159)](_0x11dd78[_0x3baa9b(0x357)], _0x4845f5));
                    }
                }
            } else _0x214907['bUtDJ'](_0x4a35dc);
        }
    })();
}());
const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    jidNormalizedUser,
    isJidBroadcast,
    getContentType,
    proto,
    generateWAMessageContent,
    generateWAMessage,
    AnyMessageContent,
    prepareWAMessageMedia,
    areJidsSameUser,
    downloadContentFromMessage,
    MessageRetryMap,
    generateForwardMessageContent,
    generateWAMessageFromContent,
    generateMessageID,
    makeInMemoryStore,
    jidDecode,
    fetchLatestBaileysVersion,
    Browsers
} = require(_0x1d324b(0x2b6)), l = console[_0x1d324b(0x266)], {
    getBuffer,
    getGroupAdmins,
    getRandom,
    h2k,
    isUrl,
    Json,
    runtime,
    sleep,
    fetchJson
} = require(_0x1d324b(0x263)), {
    AntiDelDB,
    initializeAntiDeleteSettings,
    setAnti,
    getAnti,
    getAllAntiDeleteSettings,
    saveContact,
    loadMessage,
    getName,
    getChatSummary,
    saveGroupMetadata,
    getGroupMetadata,
    saveMessageCount,
    getInactiveGroupMembers,
    getGroupMembersMessageCount,
    saveMessage
} = require(_0x1d324b(0x27a)), fs = require('fs'), ff = require(_0x1d324b(0x1d0)), P = require(_0x1d324b(0x136)), config = require(_0x1d324b(0x1ed)), GroupEvents = require('./lib/groupevents'), qrcode = require(_0x1d324b(0x178)), StickersTypes = require(_0x1d324b(0x2f7)), util = require('util'), {
    sms,
    downloadMediaMessage,
    AntiDelete
} = require(_0x1d324b(0x22c)), FileType = require('file-type'), axios = require(_0x1d324b(0x317)), {
    File
} = require('megajs'), {
    fromBuffer
} = require(_0x1d324b(0x13f)), bodyparser = require('body-parser'), {
    logActivity
} = require('./lib/activityTracker'), os = require('os'), Crypto = require('crypto'), path = require(_0x1d324b(0x39e)), {
    getPrefix
} = require(_0x1d324b(0x2c7)), ownerNumber = [_0x1d324b(0x289)], tempDir = path[_0x1d324b(0x200)](os[_0x1d324b(0x2a6)](), _0x1d324b(0x375));
!fs[_0x1d324b(0x2ae)](tempDir) && fs[_0x1d324b(0x2b7)](tempDir);
const clearTempDir = () => {
    const _0x5156a1 = _0x1d324b,
        _0x36f2fd = {};
    _0x36f2fd[_0x5156a1(0x164)] = _0x5156a1(0x28c);
    const _0x2dde77 = _0x36f2fd;
    fs[_0x5156a1(0x2b1)](tempDir, (_0x3d6baf, _0x11a6b5) => {
        const _0x552c22 = _0x5156a1,
            _0x13100d = {};
        _0x13100d[_0x552c22(0x28d)] = _0x2dde77['VIMbO'];
        const _0x2771c6 = _0x13100d;
        if (_0x3d6baf) throw _0x3d6baf;
        for (const _0x188707 of _0x11a6b5) {
            fs['unlink'](path['join'](tempDir, _0x188707), _0x4488be => {
                const _0x49adad = _0x552c22;
                if (_0x49adad(0x28c) === _0x2771c6[_0x49adad(0x28d)]) {
                    if (_0x4488be) throw _0x4488be;
                } else _0x457018['error'](_0x49adad(0x11f), _0x2cc1a2);
            });
        }
    });
};
setInterval(clearTempDir, 0x5 * 0x3c * 0x3e8);
if (!fs[_0x1d324b(0x2ae)](__dirname + _0x1d324b(0x246))) {
    if (!config['SESSION_ID']) return console[_0x1d324b(0x266)](_0x1d324b(0x31f));
    const sessdata = config['SESSION_ID'][_0x1d324b(0x2d5)]('lucky~', ''),
        filer = File[_0x1d324b(0x19f)](_0x1d324b(0x32f) + sessdata);
    filer['download']((_0x4c399e, _0x1bf447) => {
        const _0x41f433 = _0x1d324b,
            _0x57a524 = {};
        _0x57a524[_0x41f433(0x1d6)] = _0x41f433(0x27d), _0x57a524[_0x41f433(0x134)] = function (_0xeef84b, _0x182e28) {
            return _0xeef84b + _0x182e28;
        }, _0x57a524['GLvas'] = '/sessions/creds.json';
        const _0x5be469 = _0x57a524;
        if (_0x4c399e) throw _0x4c399e;
        fs['writeFile'](_0x5be469[_0x41f433(0x134)](__dirname, _0x5be469['GLvas']), _0x1bf447, () => {
            const _0x172858 = _0x41f433;
            console[_0x172858(0x266)](_0x5be469[_0x172858(0x1d6)]);
        });
    });
}
const express = require('express'),
    app = express(),
    port = process['env']['PORT'] || 0x2382;
let conn;
async function connectToWA() {
    const _0x565c93 = _0x1d324b,
        _0x4b4921 = {
            'Jjewt': function (_0x57da26, _0x13e74f) {
                return _0x57da26 === _0x13e74f;
            },
            'KlEZB': _0x565c93(0x342),
            'hGJgS': function (_0x34f386, _0xa57099) {
                return _0x34f386(_0xa57099);
            },
            'PRXkY': function (_0x2f16a2, _0x499c6c) {
                return _0x2f16a2 + _0x499c6c;
            },
            'yNwsX': './plugins/',
            'rmYwP': _0x565c93(0x2ce),
            'dKONv': '\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)',
            'MaqTb': function (_0x42870d, _0x5b4cee) {
                return _0x42870d(_0x5b4cee);
            },
            'EluUa': _0x565c93(0x359),
            'YqrOf': function (_0x5a3464) {
                return _0x5a3464();
            },
            'uBDim': _0x565c93(0x152),
            'WJuWL': 'open',
            'ZKvWQ': _0x565c93(0x299),
            'ldhlR': _0x565c93(0x2c7),
            'uJkPV': _0x565c93(0x260),
            'nqDYs': _0x565c93(0x2b9),
            'KbjxQ': _0x565c93(0x3a0),
            'NkLZg': _0x565c93(0x23b),
            'ykrzx': function (_0x5276b8, _0x469538) {
                return _0x5276b8 !== _0x469538;
            },
            'bqVOY': _0x565c93(0x35b),
            'wBjrq': function (_0xa1b53b, _0x20351f) {
                return _0xa1b53b !== _0x20351f;
            },
            'PSldr': 'rrDbm',
            'sZeRa': function (_0x1963e4, _0x3dd4af) {
                return _0x1963e4 > _0x3dd4af;
            },
            'NqFdm': function (_0x417aca, _0x4b2769) {
                return _0x417aca === _0x4b2769;
            },
            'ZJhBF': _0x565c93(0x275),
            'xUiRG': function (_0x771897, _0x4b4df3) {
                return _0x771897 === _0x4b4df3;
            },
            'TzMpS': 'dqqcr',
            'htTIp': _0x565c93(0x19d),
            'ikCOa': _0x565c93(0x23d),
            'jELWv': function (_0x5a25d8, _0x28966c) {
                return _0x5a25d8 / _0x28966c;
            },
            'rCptO': function (_0xae5837, _0xd5ffc5) {
                return _0xae5837 - _0xd5ffc5;
            },
            'DXjJm': function (_0x2f2c5d, _0x513ff4) {
                return _0x2f2c5d <= _0x513ff4;
            },
            'KQhkQ': '❌ Failed to send restart notification:',
            'HHOrn': function (_0x4b4df2, _0x519e45) {
                return _0x4b4df2 === _0x519e45;
            },
            'dZSQe': '[ ❌ ] Error during post-connect setup:',
            'mnFXN': function (_0x5173d1, _0x3c9ee3) {
                return _0x5173d1 + _0x3c9ee3;
            },
            'IHAdW': _0x565c93(0x31a),
            'GcKBo': '0@s.whatsapp.net',
            'qkvQO': _0x565c93(0x1ae),
            'UsNEH': _0x565c93(0x1a4),
            'kxsyg': function (_0x1165a5, _0x18f94c) {
                return _0x1165a5 !== _0x18f94c;
            },
            'BqZja': _0x565c93(0x367),
            'LiUTH': _0x565c93(0x20f),
            'WlTuS': function (_0x45f995, _0x4f0e67) {
                return _0x45f995 !== _0x4f0e67;
            },
            'ljctx': _0x565c93(0x294),
            'tOIab': 'extendedTextMessage',
            'Bfdeu': 'imageMessage',
            'vnLAf': _0x565c93(0x288),
            'lurzQ': 'buttonsResponseMessage',
            'OymOl': _0x565c93(0x234),
            'OdJnG': _0x565c93(0x1f0),
            'fAyoD': _0x565c93(0x29d),
            'kLrYB': function (_0x402aed, _0x252193) {
                return _0x402aed(_0x252193);
            },
            'HgXwK': 'zXAvV',
            'ijvNF': _0x565c93(0x12a),
            'qGNZg': function (_0x2bb93f, _0x327208) {
                return _0x2bb93f || _0x327208;
            },
            'QVZDG': _0x565c93(0x150),
            'BVhnX': _0x565c93(0x161),
            'hteWd': _0x565c93(0x1d9),
            'SpHzQ': function (_0x5790b0, _0x2dd357) {
                return _0x5790b0 === _0x2dd357;
            },
            'zIaXT': 'photo',
            'dvZds': function (_0x128cce, _0x1fe3ed) {
                return _0x128cce === _0x1fe3ed;
            },
            'QYmBi': 'stickerMessage',
            'wlVxg': function (_0x559244, _0x47cf7a) {
                return _0x559244 === _0x47cf7a;
            },
            'pjmqS': function (_0x4233ba, _0x71c280) {
                return _0x4233ba === _0x71c280;
            },
            'swHIW': _0x565c93(0x21e),
            'zqRbS': _0x565c93(0x15b),
            'GIIch': function (_0x28d282, _0x40746c) {
                return _0x28d282 !== _0x40746c;
            },
            'Cdatz': _0x565c93(0x16a),
            'LNxHl': function (_0x4976a5, _0xb98750) {
                return _0x4976a5 === _0xb98750;
            },
            'Swibm': function (_0x4fafa8, _0x23c56a) {
                return _0x4fafa8 !== _0x23c56a;
            },
            'TDnlQ': _0x565c93(0x1b9),
            'OITIR': _0x565c93(0x1c2),
            'NRJoP': function (_0x495b46, _0x23e95d) {
                return _0x495b46 === _0x23e95d;
            },
            'iEBeJ': function (_0x376a31, _0x341ed4, _0xe2437b) {
                return _0x376a31(_0x341ed4, _0xe2437b);
            },
            'xkJYo': function (_0x53b7ee, _0x4b13ec) {
                return _0x53b7ee(_0x4b13ec);
            },
            'GPjTT': function (_0x1ef2bc, _0x174db4) {
                return _0x1ef2bc != _0x174db4;
            },
            'CEdta': function (_0x478d8a, _0x3521aa) {
                return _0x478d8a(_0x3521aa);
            },
            'giovn': function (_0x2f8cf0) {
                return _0x2f8cf0();
            },
            'cwNAJ': function (_0x4d4ce6, _0x3ea39f) {
                return _0x4d4ce6 + _0x3ea39f;
            },
            'YRMya': 'Sin Nombre',
            'gVChj': _0x565c93(0x289),
            'OkVZa': './lib/sudo.json',
            'PYtgn': 'utf-8',
            'KmQSV': function (_0x32291c, _0x19e067) {
                return _0x32291c + _0x19e067;
            },
            'QpMgf': 'child_process',
            'eEXPN': function (_0xdd32f4, _0xeae1e8, _0x5f5207) {
                return _0xdd32f4(_0xeae1e8, _0x5f5207);
            },
            'Fjful': _0x565c93(0x1ba),
            'GyOai': _0x565c93(0x264),
            'ccykM': function (_0x377b07, _0x865120) {
                return _0x377b07(_0x865120);
            },
            'ekEyp': function (_0x4ac4f9, _0x514657) {
                return _0x4ac4f9 === _0x514657;
            },
            'sESuR': '❤‍🔥',
            'KlAch': '👩‍🦰',
            'BCNJn': _0x565c93(0x1cd),
            'PSUiq': _0x565c93(0x171),
            'ZFwYu': _0x565c93(0x14d),
            'YgTnJ': _0x565c93(0x120),
            'iSSIe': '🦹🏻‍♀️',
            'kqSts': '🧟‍♀️',
            'rhRCx': '🧞‍♀️',
            'avWpO': _0x565c93(0x14e),
            'yoJVc': '💁‍♂️',
            'HoSjJ': _0x565c93(0x254),
            'NIiml': _0x565c93(0x259),
            'ezncx': _0x565c93(0x256),
            'fXPiF': _0x565c93(0x2b4),
            'cefMY': _0x565c93(0x1e7),
            'GiwvD': '🚶‍♀️',
            'uPxup': _0x565c93(0x283),
            'WZZiS': _0x565c93(0x35e),
            'zNteu': _0x565c93(0x12b),
            'nwAIq': _0x565c93(0x35c),
            'QeQXK': _0x565c93(0x212),
            'IsHrM': _0x565c93(0x15f),
            'qNKMw': _0x565c93(0x2ee),
            'yTVOo': function (_0x556d4a, _0x31c3cc) {
                return _0x556d4a * _0x31c3cc;
            },
            'tTJfj': function (_0x4ef966, _0x3783f1) {
                return _0x4ef966 === _0x3783f1;
            },
            'UXeiC': _0x565c93(0x14f),
            'SDKlV': _0x565c93(0x33b),
            'ADpqa': _0x565c93(0x274),
            'hSsXx': function (_0x58993a, _0x3bba90) {
                return _0x58993a === _0x3bba90;
            },
            'ndjBZ': 'inbox',
            'MfPqd': function (_0x8c2c52, _0x5f7772) {
                return _0x8c2c52 && _0x5f7772;
            },
            'oXGor': 'MIKqo',
            'oEJSP': function (_0x291f57, _0x7ab404) {
                return _0x291f57(_0x7ab404);
            },
            'oWFaC': _0x565c93(0x1c3),
            'vTWzm': function (_0x7c753c, _0x16dafb) {
                return _0x7c753c(_0x16dafb);
            },
            'klubv': _0x565c93(0x149),
            'mFTMY': 'Failed to log activity:',
            'IhOpf': _0x565c93(0x1f8),
            'WdwrK': function (_0x5b451e, _0x56d57a) {
                return _0x5b451e === _0x56d57a;
            },
            'dGAIi': _0x565c93(0x147),
            'tNYcP': _0x565c93(0x306),
            'jKyvd': _0x565c93(0x1a7),
            'MdWiM': _0x565c93(0x2c6),
            'WwNUN': _0x565c93(0x291),
            'fBBXx': function (_0x182aa1, _0x1396d4) {
                return _0x182aa1(_0x1396d4);
            },
            'nsCGd': _0x565c93(0x15a),
            'xzaeb': function (_0x247fda, _0x1c131f, _0x3bf89c) {
                return _0x247fda(_0x1c131f, _0x3bf89c);
            },
            'MbRrw': function (_0x6b8425, _0x3ee057) {
                return _0x6b8425 != _0x3ee057;
            },
            'gkVuA': function (_0xa12e4a, _0x27022f) {
                return _0xa12e4a(_0x27022f);
            },
            'ZXfSV': _0x565c93(0x17e),
            'pLJmD': function (_0x8a4075, _0x273679, _0x5abb26) {
                return _0x8a4075(_0x273679, _0x5abb26);
            },
            'SNVwc': function (_0x1cb277, _0x174436) {
                return _0x1cb277 + _0x174436;
            },
            'yRMho': function (_0x2eaad6, _0x389024) {
                return _0x2eaad6 !== _0x389024;
            },
            'DUFUM': _0x565c93(0x1db),
            'ueTop': function (_0x336c00, _0x4399f1) {
                return _0x336c00 === _0x4399f1;
            },
            'zUvfP': _0x565c93(0x2d6),
            'rHexC': _0x565c93(0x385),
            'iXRAP': _0x565c93(0x160),
            'SLteN': function (_0x47a069, _0x476813) {
                return _0x47a069 === _0x476813;
            },
            'ibDPb': _0x565c93(0x187),
            'fexaQ': function (_0x2b29ab, _0x2f9c80) {
                return _0x2b29ab === _0x2f9c80;
            },
            'CTCcX': 'video',
            'rMBDg': function (_0x5a997f, _0x583cfc) {
                return _0x5a997f === _0x583cfc;
            },
            'Vrizr': function (_0x264b22, _0x57ed08) {
                return _0x264b22(_0x57ed08);
            },
            'aFTeE': 'audio/mpeg',
            'nXZVn': 'AoMuy',
            'NyLMw': 'string',
            'HJFAs': function (_0x146374, _0x4e6bb6) {
                return _0x146374 !== _0x4e6bb6;
            },
            'SlstB': _0x565c93(0x13a),
            'VkIjf': 'application/octet-stream',
            'lVsaV': _0x565c93(0x2a7),
            'PhhRz': function (_0x516a62, _0x560344) {
                return _0x516a62 + _0x560344;
            },
            'VaWlH': function (_0x51907e, _0x468fc0) {
                return _0x51907e + _0x468fc0;
            },
            'IYGWx': function (_0x28843d, _0x2bf623) {
                return _0x28843d(_0x2bf623);
            },
            'ydSMn': function (_0x5f1d7e, _0x186de2) {
                return _0x5f1d7e + _0x186de2;
            },
            'mPCQn': function (_0x2b3d0d, _0x5095dc) {
                return _0x2b3d0d === _0x5095dc;
            },
            'CkTbJ': _0x565c93(0x25b),
            'WLIAY': _0x565c93(0x1a6),
            'jCNtX': function (_0x2ad5b8, _0x2e32c0, _0x928397) {
                return _0x2ad5b8(_0x2e32c0, _0x928397);
            },
            'bKfHo': 'sticker',
            'cTZwE': _0x565c93(0x2bf),
            'NWttL': _0x565c93(0x1ab),
            'AXCFL': _0x565c93(0x354),
            'HZPVB': function (_0x2613a7, _0x23f23d) {
                return _0x2613a7(_0x23f23d);
            },
            'LTQqo': function (_0x1dfe63, _0x1a7438) {
                return _0x1dfe63 === _0x1a7438;
            },
            'ePxlQ': _0x565c93(0x361),
            'hwICg': _0x565c93(0x35a),
            'ORlwH': function (_0x289ee7, _0x2d95d4) {
                return _0x289ee7 !== _0x2d95d4;
            },
            'Fasyv': function (_0x4635c3, _0x4f472f) {
                return _0x4635c3 <= _0x4f472f;
            },
            'teOpj': 'ssejX',
            'CpPrM': _0x565c93(0x22b),
            'oQMYD': function (_0x35fc1c, _0x56ed10) {
                return _0x35fc1c(_0x56ed10);
            },
            'Baabl': function (_0x5e273a, _0x3708da) {
                return _0x5e273a === _0x3708da;
            },
            'yfWTr': 'uagdF',
            'pJmKk': _0x565c93(0x224),
            'UILkw': _0x565c93(0x250),
            'xhzjU': function (_0x50a66a, _0x3ba418) {
                return _0x50a66a(_0x3ba418);
            },
            'BVZQl': function (_0x5239a5, _0x41c3e5) {
                return _0x5239a5(_0x41c3e5);
            },
            'segGb': _0x565c93(0x1a8),
            'TCoFW': _0x565c93(0x1a9),
            'WbIdU': function (_0x5b3401, _0x426115) {
                return _0x5b3401 !== _0x426115;
            },
            'HXQPo': _0x565c93(0x12c),
            'GPBJu': function (_0x587849, _0x2acc81, _0x57ac65) {
                return _0x587849(_0x2acc81, _0x57ac65);
            },
            'iMLAt': function (_0x3ac7e0, _0x2f7252, _0x11f49a, _0x1f69c0) {
                return _0x3ac7e0(_0x2f7252, _0x11f49a, _0x1f69c0);
            },
            'dKzal': function (_0x356aa0, _0x2fa0be) {
                return _0x356aa0 + _0x2fa0be;
            },
            'pqiKl': _0x565c93(0x15c),
            'tEBqf': function (_0x254571, _0x56c228) {
                return _0x254571 + _0x56c228;
            },
            'uRLCA': _0x565c93(0x137),
            'Bpxpg': function (_0x27701b, _0x3999e0) {
                return _0x27701b + _0x3999e0;
            },
            'YMBew': _0x565c93(0x3a2),
            'ouBpw': 'status',
            'eeGOM': '[ 🟠 ] Connecting to WhatsApp ⏳️...',
            'rlwlX': _0x565c93(0x232),
            'orZXW': function (_0x7f2f2e) {
                return _0x7f2f2e();
            },
            'CiAbO': function (_0x2e8cda, _0x4ca201) {
                return _0x2e8cda(_0x4ca201);
            },
            'xIZAi': _0x565c93(0x251),
            'OHYqe': _0x565c93(0x1a0),
            'IiQtg': _0x565c93(0x2a4),
            'WtNVQ': function (_0x23b777, _0x44242a) {
                return _0x23b777 !== _0x44242a;
            },
            'suKbi': 'vZnED',
            'kmRTr': _0x565c93(0x11f),
            'acGlD': 'messages.update',
            'cqmqd': _0x565c93(0x13d)
        };
    try {
        console['log'](_0x4b4921[_0x565c93(0x257)]);
        const {
            state: _0x1aee39,
            saveCreds: _0x2f3179
        } = await _0x4b4921[_0x565c93(0x11d)](useMultiFileAuthState, __dirname + _0x4b4921[_0x565c93(0x2a9)]), {
            version: _0x54626c
        } = await _0x4b4921['orZXW'](fetchLatestBaileysVersion);
        conn = makeWASocket({
            'logger': _0x4b4921[_0x565c93(0x239)](P, {
                'level': _0x4b4921[_0x565c93(0x22a)]
            }),
            'printQRInTerminal': ![],
            'browser': Browsers['macOS'](_0x4b4921[_0x565c93(0x172)]),
            'syncFullHistory': !![],
            'auth': _0x1aee39,
            'version': _0x54626c
        }), conn['ev']['on'](_0x4b4921[_0x565c93(0x2dd)], async _0x3b14cc => {
            const _0x27257f = _0x565c93,
                _0x3a96cf = {};
            _0x3a96cf[_0x27257f(0x18b)] = function (_0x3a7211, _0x4e6b0b) {
                return _0x3a7211 + _0x4e6b0b;
            };
            const _0x24f34c = _0x3a96cf,
                {
                    connection: _0x389534,
                    lastDisconnect: _0x45a271
                } = _0x3b14cc;
            if (_0x4b4921['Jjewt'](_0x389534, _0x4b4921['uBDim'])) {
                const _0x4a3c98 = _0x45a271?. ['error']?. ['output']?. [_0x27257f(0x374)] !== DisconnectReason['loggedOut'];
                _0x4a3c98 && await _0x4b4921['YqrOf'](connectToWA);
            } else {
                if (_0x389534 === _0x4b4921[_0x27257f(0x144)]) try {
                    console[_0x27257f(0x266)](_0x4b4921[_0x27257f(0x27f)]);
                    let _0x46de71 = 0x0;
                    fs[_0x27257f(0x167)](_0x27257f(0x25c))[_0x27257f(0x1fb)](_0x144a83 => {
                        const _0x23bc18 = _0x27257f;
                        _0x4b4921['Jjewt'](path[_0x23bc18(0x2f3)](_0x144a83)['toLowerCase'](), _0x4b4921[_0x23bc18(0x258)]) && (_0x4b4921[_0x23bc18(0x1b0)](require, _0x4b4921[_0x23bc18(0x132)](_0x4b4921[_0x23bc18(0x365)], _0x144a83)), _0x46de71++);
                    }), console[_0x27257f(0x266)](_0x27257f(0x1cb) + _0x46de71 + _0x27257f(0x20c)), console[_0x27257f(0x266)](_0x27257f(0x2c3));
                    const {
                        getPrefix: _0x156467
                    } = require(_0x4b4921['ldhlR']), _0x30de4a = _0x156467(), _0x19dfb1 = _0x27257f(0x129) + _0x30de4a + _0x27257f(0x1c7) + _0x46de71 + _0x27257f(0x11b) + _0x30de4a + 'prefix\x0a\x0a⭐ GitHub:\x0ahttps://github.com/Tomilucky218/Lucky-XD2\x0a\x0a> © Powered By Lucky Tech Hub\x0a\x0a';
                    await conn[_0x27257f(0x2bb)](_0x4b4921['PRXkY'](ownerNumber[0x0], _0x4b4921[_0x27257f(0x1f3)]), {
                        'image': {
                            'url': _0x4b4921[_0x27257f(0x39c)]
                        },
                        'caption': _0x19dfb1
                    });
                    const _0x21e3b3 = [_0x4b4921[_0x27257f(0x1f6)], _0x27257f(0x207), _0x4b4921[_0x27257f(0x21f)]];
                    let _0x24657a = [],
                        _0x17f744 = [];
                    for (const _0x5d8895 of _0x21e3b3) {
                        try {
                            if (_0x4b4921[_0x27257f(0x36b)](_0x4b4921[_0x27257f(0x23f)], _0x4b4921[_0x27257f(0x23f)])) {
                                const _0x46a29c = {};
                                _0x46a29c[_0x27257f(0x213)] = _0x44407f, _0x46a29c['l'] = _0x4f0774, _0x46a29c[_0x27257f(0x30a)] = _0x3bf9e5, _0x46a29c[_0x27257f(0x150)] = _0x27499f, _0x46a29c[_0x27257f(0x28e)] = _0x133f6f, _0x46a29c[_0x27257f(0x2e5)] = _0x460d03, _0x46a29c[_0x27257f(0x380)] = _0x2d714a, _0x46a29c['q'] = _0x435dd1, _0x46a29c[_0x27257f(0x161)] = _0x1f20f7, _0x46a29c['isGroup'] = _0x53ecaa, _0x46a29c[_0x27257f(0x25d)] = _0x18df0a, _0x46a29c[_0x27257f(0x240)] = _0x1a4d61, _0x46a29c[_0x27257f(0x1bf)] = _0x4bf809, _0x46a29c[_0x27257f(0x1b8)] = _0x1537c8, _0x46a29c['pushname'] = _0x59bc98, _0x46a29c[_0x27257f(0x305)] = _0x11d8b8, _0x46a29c[_0x27257f(0x1eb)] = _0x3bba45, _0x46a29c[_0x27257f(0x18a)] = _0x1ce01e, _0x46a29c['groupMetadata'] = _0x13165b, _0x46a29c[_0x27257f(0x29e)] = _0x2c9cf8, _0x46a29c['participants'] = _0x1a53a9, _0x46a29c[_0x27257f(0x24f)] = _0x5afc75, _0x46a29c[_0x27257f(0x199)] = _0x4b3d7e, _0x46a29c['isAdmins'] = _0x2fd8ce, _0x46a29c[_0x27257f(0x17a)] = _0x518c20, _0x5cadf2['function'](_0x20f3a8, _0x55f0a0, _0x9caf60, _0x46a29c);
                            } else await conn[_0x27257f(0x36d)](_0x5d8895), _0x24657a[_0x27257f(0x215)](_0x5d8895);
                        } catch (_0x2c7155) {
                            _0x4b4921[_0x27257f(0x181)](_0x27257f(0x371), _0x4b4921[_0x27257f(0x1dc)]) ? _0x4b4921[_0x27257f(0x1b0)](_0x571abe, _0x19b28a[_0x27257f(0x372)]()) : (_0x17f744[_0x27257f(0x215)](_0x5d8895), console[_0x27257f(0x264)](_0x27257f(0x37e) + _0x5d8895 + ':', _0x2c7155));
                        }
                    }
                    let _0x114e7d = _0x4b4921['PRXkY'](_0x4b4921[_0x27257f(0x132)]('📡 Newsletter Follow Status:\x0a\x0a' + (_0x27257f(0x231) + _0x24657a[_0x27257f(0x1fc)] + _0x27257f(0x347)), _0x4b4921['sZeRa'](_0x17f744[_0x27257f(0x1fc)], 0x0) ? _0x27257f(0x37e) + _0x17f744[_0x27257f(0x1fc)] + _0x27257f(0x2fc) : '\x0a'), _0x27257f(0x323));
                    if (_0x4b4921[_0x27257f(0x34a)](_0x17f744[_0x27257f(0x1fc)], 0x0)) {
                        if (_0x4b4921['NqFdm'](_0x4b4921[_0x27257f(0x218)], _0x4b4921[_0x27257f(0x218)])) _0x114e7d += _0x27257f(0x1d8) + _0x17f744[_0x27257f(0x1fc)] + _0x27257f(0x26b);
                        else return _0x157fcf;
                    }
                    console[_0x27257f(0x266)](_0x114e7d[_0x27257f(0x223)]());
                    const _0x118f07 = path[_0x27257f(0x200)](__dirname, _0x27257f(0x206));
                    if (fs[_0x27257f(0x2ae)](_0x118f07)) {
                        if (_0x4b4921['xUiRG'](_0x27257f(0x335), _0x4b4921[_0x27257f(0x2d3)])) try {
                            if (_0x4b4921[_0x27257f(0x180)] === _0x4b4921[_0x27257f(0x282)]) {
                                let _0x618d52 = _0x1d4f01(_0x1f8c36) || {};
                                return _0x618d52[_0x27257f(0x16f)] && _0x618d52[_0x27257f(0x314)] && _0x24f34c['UpjUQ'](_0x618d52['user'] + '@', _0x618d52[_0x27257f(0x314)]) || _0x437f3c;
                            } else {
                                const _0x51f37f = JSON[_0x27257f(0x26e)](fs[_0x27257f(0x154)](_0x118f07)),
                                    _0x4ee25a = Date[_0x27257f(0x201)](),
                                    _0x36178c = fs[_0x27257f(0x28a)](_0x118f07)[_0x27257f(0x271)],
                                    _0x3a091d = _0x4b4921[_0x27257f(0x1f4)](_0x4b4921[_0x27257f(0x353)](_0x4ee25a, _0x36178c), 0x3e8);
                                if (_0x4b4921[_0x27257f(0x2c0)](_0x3a091d, 0xb4)) {
                                    const _0x72bfb5 = _0x27257f(0x326) + _0x51f37f[_0x27257f(0x25d)][_0x27257f(0x30b)]('@')[0x0] + '> restart completed successfully.\x0a';
                                    await conn['sendMessage'](_0x51f37f[_0x27257f(0x202)], {
                                        'text': _0x72bfb5,
                                        'mentions': [_0x51f37f[_0x27257f(0x25d)]]
                                    });
                                }
                                fs[_0x27257f(0x2ef)](_0x118f07);
                            }
                        } catch (_0x21881f) {
                            console[_0x27257f(0x264)](_0x4b4921[_0x27257f(0x19c)], _0x21881f);
                        } else return ![];
                    }
                } catch (_0x13570e) {
                    if (_0x4b4921['HHOrn'](_0x27257f(0x37c), 'xqUNC')) console['error'](_0x4b4921[_0x27257f(0x34e)], _0x13570e);
                    else {
                        const _0x20395a = new _0x29f4f7(QrLJVg[_0x27257f(0x135)]),
                            _0x14b78d = new _0x1576aa(QrLJVg[_0x27257f(0x2ec)], 'i'),
                            _0x374836 = QrLJVg[_0x27257f(0x153)](_0x2b7162, QrLJVg[_0x27257f(0x2f0)]);
                        !_0x20395a[_0x27257f(0x2a2)](QrLJVg[_0x27257f(0x132)](_0x374836, _0x27257f(0x287))) || !_0x14b78d[_0x27257f(0x2a2)](_0x374836 + _0x27257f(0x31c)) ? _0x374836('0') : QrLJVg['YqrOf'](_0x439f);
                    }
                }
            }
        }), conn['ev']['on']('creds.update', _0x2f3179);
    } catch (_0x10156c) {
        if (_0x4b4921[_0x565c93(0x192)](_0x4b4921[_0x565c93(0x1d5)], _0x4b4921['suKbi'])) return [..._0x1753bd[_0x565c93(0x1da)](/@([0-9]{5,16}|0)/g)][_0x565c93(0x37f)](_0x112e2f => _0x112e2f[0x1] + _0x565c93(0x260));
        else console['error'](_0x4b4921[_0x565c93(0x296)], _0x10156c);
    }
    conn?. ['ev']?. ['on'](_0x4b4921[_0x565c93(0x334)], async _0x3cb5d7 => {
        const _0x721bb8 = _0x565c93,
            _0x52c9d4 = {
                'EDCwT': function (_0x2507fe, _0x544b32) {
                    const _0x4c637c = _0x4fdc;
                    return _0x4b4921[_0x4c637c(0x1b0)](_0x2507fe, _0x544b32);
                },
                'cPhpA': function (_0x4f9508, _0x5ca558) {
                    return _0x4b4921['mnFXN'](_0x4f9508, _0x5ca558);
                },
                'pJVkV': _0x4b4921[_0x721bb8(0x331)],
                'JhwiD': function (_0x3cb5a2, _0x511eb1) {
                    return _0x3cb5a2 === _0x511eb1;
                },
                'MObSP': _0x4b4921[_0x721bb8(0x13b)],
                'izQQg': _0x4b4921['qkvQO'],
                'dbXhN': '@s.whatsapp.net',
                'HaBmy': _0x721bb8(0x333)
            };
        if (_0x4b4921[_0x721bb8(0x36b)](_0x4b4921[_0x721bb8(0x1fe)], _0x4b4921['UsNEH'])) {
            _0x35ab37 = _0x3c4184['decodeJid'](_0x513491), _0x44282b = _0x4d7821[_0x721bb8(0x1af)] || _0x335cbb;
            let _0x49eec8;
            if (_0x3b0cd9['endsWith'](_0x721bb8(0x15c))) return new _0x15cf15(async _0x1975b6 => {
                const _0x104e0b = _0x721bb8;
                _0x49eec8 = _0xf35d08[_0x104e0b(0x34b)][_0x18e17c] || {};
                if (!(_0x49eec8[_0x104e0b(0x2e1)][_0x104e0b(0x378)] || _0x49eec8[_0x104e0b(0x2cb)])) _0x49eec8 = _0xdf957b[_0x104e0b(0x1e2)](_0xccc2e9) || {};
                _0x1975b6(_0x49eec8[_0x104e0b(0x2e1)] || _0x49eec8[_0x104e0b(0x2cb)] || _0x52c9d4[_0x104e0b(0x204)](_0x5db306, _0x52c9d4[_0x104e0b(0x391)]('+', _0x3088ca[_0x104e0b(0x2d5)](_0x104e0b(0x260), '')))[_0x104e0b(0x32a)](_0x52c9d4[_0x104e0b(0x29c)]));
            });
            else _0x49eec8 = _0x52c9d4[_0x721bb8(0x24d)](_0x5b4e3d, _0x52c9d4[_0x721bb8(0x1b3)]) ? {
                'id': _0x398042,
                'name': _0x52c9d4[_0x721bb8(0x2ed)]
            } : _0x52c9d4['JhwiD'](_0x525f70, _0x52b55d['decodeJid'](_0x465da4[_0x721bb8(0x16f)]['id'])) ? _0x32a42d['user'] : _0x234fcb[_0x721bb8(0x34b)][_0x256b97] || {};
            return (_0x1af257 ? '' : _0x49eec8[_0x721bb8(0x2e1)]) || _0x49eec8['subject'] || _0x49eec8[_0x721bb8(0x2f1)] || _0x52c9d4['EDCwT'](_0x66a728, _0x52c9d4['cPhpA']('+', _0x42fd53[_0x721bb8(0x2d5)](_0x52c9d4[_0x721bb8(0x2ba)], '')))['getNumber'](_0x52c9d4[_0x721bb8(0x29c)]);
        } else
            for (const _0x264b93 of _0x3cb5d7) {
                _0x4b4921[_0x721bb8(0x2c2)](_0x4b4921[_0x721bb8(0x1e4)], _0x4b4921[_0x721bb8(0x1e4)]) ? _0x1c2c00[_0x721bb8(0x264)](_0x52c9d4[_0x721bb8(0x30d)], _0x3de437) : _0x4b4921[_0x721bb8(0x1d2)](_0x264b93['update'][_0x721bb8(0x1ac)], null) && (console['log'](_0x721bb8(0x363), JSON[_0x721bb8(0x33f)](_0x264b93, null, 0x2)), await AntiDelete(conn, _0x3cb5d7));
            }
    }), conn['ev']['on'](_0x565c93(0x183), _0x43ff07 => GroupEvents(conn, _0x43ff07)), conn['ev']['on'](_0x4b4921[_0x565c93(0x3a1)], async _0x42fc9e => {
        const _0x5cfc72 = _0x565c93,
            _0x4576db = {
                'WdlEy': function (_0x330d73, _0x2ac87b) {
                    return _0x330d73 === _0x2ac87b;
                },
                'EcLEC': _0x5cfc72(0x342),
                'YHksr': function (_0x1bba4b, _0x3c01d6) {
                    return _0x1bba4b(_0x3c01d6);
                },
                'oVAzL': function (_0x268726, _0xa48d21) {
                    return _0x4b4921['mnFXN'](_0x268726, _0xa48d21);
                },
                'TDNKf': _0x4b4921[_0x5cfc72(0x1bd)],
                'MSSXR': _0x4b4921[_0x5cfc72(0x37a)],
                'IsgdI': _0x4b4921[_0x5cfc72(0x2f4)],
                'GlKpo': _0x4b4921[_0x5cfc72(0x397)],
                'waheq': _0x4b4921[_0x5cfc72(0x16c)],
                'eyHUn': function (_0x4c04c2, _0x570acb) {
                    return _0x4b4921['kLrYB'](_0x4c04c2, _0x570acb);
                },
                'MvIKb': function (_0x10a25e, _0x43f203) {
                    const _0x166dab = _0x5cfc72;
                    return _0x4b4921[_0x166dab(0x1b0)](_0x10a25e, _0x43f203);
                },
                'APhNQ': _0x4b4921[_0x5cfc72(0x331)],
                'wLlmJ': function (_0xced62f, _0x485474) {
                    return _0xced62f !== _0x485474;
                },
                'IWiac': _0x5cfc72(0x238),
                'gZtFA': _0x4b4921[_0x5cfc72(0x1e0)],
                'JMRRO': _0x4b4921[_0x5cfc72(0x11e)],
                'bXddv': _0x5cfc72(0x15d),
                'fHarC': function (_0x1fa0ca, _0x28a8f4) {
                    const _0x10474c = _0x5cfc72;
                    return _0x4b4921[_0x10474c(0x336)](_0x1fa0ca, _0x28a8f4);
                },
                'TwrHO': _0x4b4921[_0x5cfc72(0x1f3)],
                'DhthM': function (_0x51fe33, _0x33c908) {
                    return _0x51fe33 === _0x33c908;
                },
                'xoiin': _0x4b4921['QVZDG'],
                'OmHLL': _0x4b4921[_0x5cfc72(0x168)],
                'xEoOl': function (_0x5658ab, _0x1593ea) {
                    return _0x5658ab === _0x1593ea;
                },
                'YuOqe': _0x4b4921[_0x5cfc72(0x228)],
                'abUiO': function (_0x3e99c0, _0x3ddc54) {
                    const _0x2510e5 = _0x5cfc72;
                    return _0x4b4921[_0x2510e5(0x165)](_0x3e99c0, _0x3ddc54);
                },
                'wWzSN': _0x4b4921[_0x5cfc72(0x34c)],
                'zraIf': 'imageMessage',
                'nWvOQ': function (_0x235cb7, _0xba23c9) {
                    const _0x3afa7c = _0x5cfc72;
                    return _0x4b4921[_0x3afa7c(0x17c)](_0x235cb7, _0xba23c9);
                },
                'lMXKs': _0x4b4921[_0x5cfc72(0x324)]
            };
        _0x42fc9e = _0x42fc9e['messages'][0x0];
        if (!_0x42fc9e[_0x5cfc72(0x1ac)]) return;
        _0x42fc9e[_0x5cfc72(0x1ac)] = _0x4b4921['wlVxg'](_0x4b4921[_0x5cfc72(0x1b0)](getContentType, _0x42fc9e['message']), _0x4b4921['ijvNF']) ? _0x42fc9e['message'][_0x5cfc72(0x12a)][_0x5cfc72(0x1ac)] : _0x42fc9e[_0x5cfc72(0x1ac)];
        _0x4b4921['pjmqS'](config[_0x5cfc72(0x399)], _0x4b4921['swHIW']) && (await conn[_0x5cfc72(0x143)]([_0x42fc9e[_0x5cfc72(0x358)]]), console[_0x5cfc72(0x266)](_0x5cfc72(0x2eb) + _0x42fc9e[_0x5cfc72(0x358)][_0x5cfc72(0x169)] + ' as read.'));
        if (_0x42fc9e['message'][_0x5cfc72(0x16b)]) _0x42fc9e[_0x5cfc72(0x1ac)] = _0x4b4921[_0x5cfc72(0x222)](_0x4b4921[_0x5cfc72(0x23e)](getContentType, _0x42fc9e[_0x5cfc72(0x1ac)]), _0x4b4921[_0x5cfc72(0x11e)]) ? _0x42fc9e['message']['ephemeralMessage'][_0x5cfc72(0x1ac)] : _0x42fc9e[_0x5cfc72(0x1ac)];
        _0x42fc9e[_0x5cfc72(0x358)] && _0x4b4921[_0x5cfc72(0x286)](_0x42fc9e[_0x5cfc72(0x358)][_0x5cfc72(0x169)], _0x4b4921['zqRbS']) && _0x4b4921[_0x5cfc72(0x328)](config['AUTO_STATUS_SEEN'], _0x4b4921[_0x5cfc72(0x235)]) && (_0x4b4921[_0x5cfc72(0x284)](_0x4b4921[_0x5cfc72(0x21d)], _0x4b4921[_0x5cfc72(0x21d)]) ? _0x4576db[_0x5cfc72(0x1ec)](_0xf6b14b[_0x5cfc72(0x2f3)](_0xf3f0bb)['toLowerCase'](), _0x4576db[_0x5cfc72(0x2c4)]) && (_0x4576db[_0x5cfc72(0x220)](_0x34c229, _0x4576db[_0x5cfc72(0x395)](_0x5cfc72(0x25c), _0x4a202a)), _0x21db21++) : await conn[_0x5cfc72(0x143)]([_0x42fc9e['key']]));
        if (_0x42fc9e[_0x5cfc72(0x358)] && _0x42fc9e[_0x5cfc72(0x358)][_0x5cfc72(0x169)] === 'status@broadcast' && _0x4b4921['LNxHl'](config[_0x5cfc72(0x26c)], 'true')) {
            if (_0x4b4921[_0x5cfc72(0x182)](_0x4b4921[_0x5cfc72(0x1e1)], _0x5cfc72(0x1b9))) {
                const _0x168fe0 = _0x63ac16 ? function () {
                    const _0x787e86 = _0x5cfc72;
                    if (_0x29424c) {
                        const _0x3c80a2 = _0x5df276[_0x787e86(0x320)](_0x33032a, arguments);
                        return _0x5711d2 = null, _0x3c80a2;
                    }
                } : function () {};
                return _0x50c92e = ![], _0x168fe0;
            } else {
                const _0x393f34 = await conn[_0x5cfc72(0x176)](conn[_0x5cfc72(0x16f)]['id']),
                    _0x3d449d = ['❤️', '💸', '😇', '🍂', '💥', '💯', '🔥', '💫', '💎', '💗', '🤍', '🖤', '👀', '🙌', '🙆', '🚩', '🥰', '💐', '😎', '🤎', '✅', '🫀', '🧡', '😁', '😄', '🌸', _0x4b4921[_0x5cfc72(0x156)], '🌷', '⛅', '🌟', '🗿', _0x5cfc72(0x20b), '💜', '💙', '🌝', '🖤', '💚'],
                    _0x493899 = _0x3d449d[Math[_0x5cfc72(0x2c5)](Math['random']() * _0x3d449d['length'])];
                await conn[_0x5cfc72(0x2bb)](_0x42fc9e[_0x5cfc72(0x358)][_0x5cfc72(0x169)], {
                    'react': {
                        'text': _0x493899,
                        'key': _0x42fc9e['key']
                    }
                }, {
                    'statusJidList': [_0x42fc9e['key'][_0x5cfc72(0x188)], _0x393f34]
                });
            }
        }
        if (_0x42fc9e[_0x5cfc72(0x358)] && _0x4b4921[_0x5cfc72(0x174)](_0x42fc9e[_0x5cfc72(0x358)][_0x5cfc72(0x169)], 'status@broadcast') && config[_0x5cfc72(0x1c1)] === _0x4b4921['swHIW']) {
            const _0x5055df = _0x42fc9e['key']['participant'],
                _0x14541f = '' + config[_0x5cfc72(0x237)],
                _0x5c8379 = {};
            _0x5c8379['text'] = '💜', _0x5c8379[_0x5cfc72(0x358)] = _0x42fc9e[_0x5cfc72(0x358)];
            const _0x1745f3 = {};
            _0x1745f3[_0x5cfc72(0x161)] = _0x14541f, _0x1745f3[_0x5cfc72(0x364)] = _0x5c8379;
            const _0x500bf5 = {};
            _0x500bf5[_0x5cfc72(0x30a)] = _0x42fc9e, await conn[_0x5cfc72(0x2bb)](_0x5055df, _0x1745f3, _0x500bf5);
        }
        await Promise['all']([_0x4b4921[_0x5cfc72(0x23e)](saveMessage, _0x42fc9e)]);
        const _0x2f7b70 = _0x4b4921[_0x5cfc72(0x1e3)](sms, conn, _0x42fc9e),
            _0x339258 = _0x4b4921[_0x5cfc72(0x11d)](getContentType, _0x42fc9e[_0x5cfc72(0x1ac)]),
            _0x5b73a3 = JSON['stringify'](_0x42fc9e[_0x5cfc72(0x1ac)]),
            _0x1f679e = _0x42fc9e[_0x5cfc72(0x358)][_0x5cfc72(0x169)],
            _0x21d9b5 = _0x339258 === _0x4b4921['tOIab'] && _0x4b4921[_0x5cfc72(0x185)](_0x42fc9e[_0x5cfc72(0x1ac)][_0x5cfc72(0x315)][_0x5cfc72(0x141)], null) ? _0x42fc9e[_0x5cfc72(0x1ac)][_0x5cfc72(0x315)]['contextInfo'][_0x5cfc72(0x18f)] || [] : [];

        function _0x56a5f4(_0x917e1b) {
            const _0xdc34d2 = _0x5cfc72;
            try {
                switch (_0x339258) {
                case _0x4576db[_0xdc34d2(0x22e)]:
                    return _0x917e1b[_0xdc34d2(0x1ac)][_0xdc34d2(0x294)];
                case _0x4576db[_0xdc34d2(0x194)]:
                    return _0x917e1b[_0xdc34d2(0x1ac)][_0xdc34d2(0x315)][_0xdc34d2(0x161)];
                case _0xdc34d2(0x17b):
                    return _0x917e1b[_0xdc34d2(0x1ac)]['imageMessage'][_0xdc34d2(0x281)] || '';
                case _0x4576db[_0xdc34d2(0x383)]:
                    return _0x917e1b[_0xdc34d2(0x1ac)][_0xdc34d2(0x1f0)][_0xdc34d2(0x281)] || '';
                case _0xdc34d2(0x288):
                    return _0x917e1b['message'][_0xdc34d2(0x288)][_0xdc34d2(0x281)] || '';
                case _0x4576db[_0xdc34d2(0x356)]:
                    return _0x917e1b[_0xdc34d2(0x1ac)][_0xdc34d2(0x377)][_0xdc34d2(0x30f)] || '';
                case 'listResponseMessage':
                    return _0x917e1b[_0xdc34d2(0x1ac)][_0xdc34d2(0x234)][_0xdc34d2(0x226)][_0xdc34d2(0x279)] || '';
                case _0x4576db['waheq']:
                    return _0x917e1b[_0xdc34d2(0x1ac)][_0xdc34d2(0x29d)][_0xdc34d2(0x2bd)] || '';
                default:
                    return '';
                }
            } catch {
                return '';
            }
        }
        const _0x364cda = _0x4b4921[_0x5cfc72(0x393)](_0x56a5f4, _0x42fc9e),
            _0x3a6e61 = _0x4b4921[_0x5cfc72(0x24c)](getPrefix),
            _0x48f50d = _0x364cda[_0x5cfc72(0x2d2)](_0x3a6e61),
            _0x23df95 = _0x48f50d ? _0x364cda[_0x5cfc72(0x388)](_0x3a6e61['length'])['trim']()[_0x5cfc72(0x30b)](' ')[0x0][_0x5cfc72(0x31d)]() : '',
            _0x37147 = _0x364cda[_0x5cfc72(0x223)]()[_0x5cfc72(0x30b)](/ +/)[_0x5cfc72(0x388)](0x1),
            _0x3c5d45 = _0x37147[_0x5cfc72(0x200)](' '),
            _0x4fb55d = _0x37147[_0x5cfc72(0x200)](' '),
            _0x4b49e5 = _0x1f679e['endsWith'](_0x5cfc72(0x15c)),
            _0x3b42df = _0x42fc9e[_0x5cfc72(0x358)][_0x5cfc72(0x166)] ? _0x4b4921[_0x5cfc72(0x1ce)](conn[_0x5cfc72(0x16f)]['id']['split'](':')[0x0], _0x4b4921[_0x5cfc72(0x1f3)]) || conn[_0x5cfc72(0x16f)]['id'] : _0x42fc9e[_0x5cfc72(0x358)][_0x5cfc72(0x188)] || _0x42fc9e[_0x5cfc72(0x358)][_0x5cfc72(0x169)],
            _0x443929 = _0x3b42df[_0x5cfc72(0x30b)]('@')[0x0],
            _0x251283 = conn[_0x5cfc72(0x16f)]['id']['split'](':')[0x0],
            _0x322c18 = _0x42fc9e[_0x5cfc72(0x270)] || _0x4b4921[_0x5cfc72(0x139)],
            _0x21e557 = _0x251283[_0x5cfc72(0x13e)](_0x443929),
            _0x39318a = ownerNumber[_0x5cfc72(0x13e)](_0x443929) || _0x21e557,
            _0x5ef90f = await jidNormalizedUser(conn[_0x5cfc72(0x16f)]['id']),
            _0x1a3463 = _0x4b49e5 ? await conn['groupMetadata'](_0x1f679e)['catch'](_0x236d92 => {}) : '',
            _0xe0388d = _0x4b49e5 ? _0x1a3463[_0x5cfc72(0x2cb)] : '',
            _0x598289 = _0x4b49e5 ? await _0x1a3463['participants'] : '',
            _0x4b7cc5 = _0x4b49e5 ? await _0x4b4921[_0x5cfc72(0x11d)](getGroupAdmins, _0x598289) : '',
            _0x3cd7b0 = _0x4b49e5 ? _0x4b7cc5[_0x5cfc72(0x13e)](_0x5ef90f) : ![],
            _0x122dca = _0x4b49e5 ? _0x4b7cc5[_0x5cfc72(0x13e)](_0x3b42df) : ![],
            _0x127cf5 = _0x2f7b70['message']?. [_0x5cfc72(0x368)] ? !![] : ![],
            _0x1f063e = _0x1d8ba6 => {
                const _0xd7a4e2 = _0x5cfc72,
                    _0x449957 = {};
                _0x449957[_0xd7a4e2(0x161)] = _0x1d8ba6;
                const _0x37078f = {};
                _0x37078f[_0xd7a4e2(0x30a)] = _0x42fc9e, conn[_0xd7a4e2(0x2bb)](_0x1f679e, _0x449957, _0x37078f);
            },
            _0x1fc752 = _0x251283[_0x5cfc72(0x30b)]('@')[0x0],
            _0x1cdb3e = ('254752818245', _0x4b4921['gVChj'], _0x5cfc72(0x2e7)),
            _0x2fb5c5 = JSON['parse'](fs['readFileSync'](_0x4b4921[_0x5cfc72(0x2bc)], _0x4b4921[_0x5cfc72(0x304)]));
        let _0x352637 = [_0x1fc752, ..._0x1cdb3e, _0x4b4921[_0x5cfc72(0x2f5)](config['DEV'], _0x4b4921[_0x5cfc72(0x1f3)]), ..._0x2fb5c5][_0x5cfc72(0x37f)](_0x1fef6b => _0x1fef6b[_0x5cfc72(0x2d5)](/[^0-9]/g, '') + _0x5cfc72(0x260))[_0x5cfc72(0x13e)](_0x42fc9e['sender']);
        if (_0x352637 && _0x42fc9e[_0x5cfc72(0x161)][_0x5cfc72(0x2d2)]('&')) {
            if (_0x4b4921['Jjewt'](_0x5cfc72(0x290), _0x5cfc72(0x290))) {
                let _0x2c4e75 = budy[_0x5cfc72(0x388)](0x2);
                if (!_0x2c4e75) {
                    _0x1f063e(_0x5cfc72(0x24b));
                    return;
                }
                const {
                    spawn: _0xd90234
                } = _0x4b4921['MaqTb'](require, _0x4b4921[_0x5cfc72(0x193)]);
                try {
                    const _0x1c3eb2 = {};
                    _0x1c3eb2[_0x5cfc72(0x384)] = !![];
                    let _0x20cf00 = _0x4b4921[_0x5cfc72(0x29b)](_0xd90234, _0x2c4e75, _0x1c3eb2);
                    _0x20cf00[_0x5cfc72(0x369)]['on'](_0x5cfc72(0x1ba), _0x29c582 => {
                        const _0x413407 = _0x5cfc72;
                        _0x4576db[_0x413407(0x2dc)](_0x1f063e, _0x29c582[_0x413407(0x372)]());
                    }), _0x20cf00[_0x5cfc72(0x38c)]['on'](_0x4b4921['Fjful'], _0x5826a9 => {
                        const _0x11206e = _0x5cfc72,
                            _0x4306af = {
                                'InQOV': function (_0xbf9f39, _0x4fad3d) {
                                    return _0xbf9f39(_0x4fad3d);
                                },
                                'wcsbo': function (_0x1a3294, _0x517567) {
                                    const _0x4c4364 = _0x4fdc;
                                    return _0x4576db[_0x4c4364(0x38e)](_0x1a3294, _0x517567);
                                },
                                'EFhbo': function (_0x16011a, _0x27c409) {
                                    const _0x41b8ee = _0x4fdc;
                                    return _0x4576db[_0x41b8ee(0x395)](_0x16011a, _0x27c409);
                                },
                                'PgLAo': _0x11206e(0x260),
                                'xzxNJ': _0x4576db[_0x11206e(0x379)]
                            };
                        if (_0x4576db[_0x11206e(0x25e)](_0x4576db[_0x11206e(0x1c8)], _0x4576db[_0x11206e(0x319)])) _0x4576db[_0x11206e(0x38e)](_0x1f063e, _0x5826a9['toString']());
                        else {
                            _0x19a9cb = _0x5e089f[_0x11206e(0x34b)][_0x49bff9] || {};
                            if (!(_0xc88ebf[_0x11206e(0x2e1)][_0x11206e(0x378)] || _0x58fe9a[_0x11206e(0x2cb)])) _0xabaa13 = _0x241783[_0x11206e(0x1e2)](_0x3585b5) || {};
                            _0x4306af['InQOV'](_0x70b8d5, _0x5055bd[_0x11206e(0x2e1)] || _0x554f9e[_0x11206e(0x2cb)] || _0x4306af[_0x11206e(0x17d)](_0x314517, _0x4306af[_0x11206e(0x2af)]('+', _0x2c37e8['replace'](_0x4306af['PgLAo'], '')))[_0x11206e(0x32a)](_0x4306af[_0x11206e(0x146)]));
                        }
                    }), _0x20cf00['on'](_0x4b4921[_0x5cfc72(0x125)], _0x401066 => {
                        const _0x15fe89 = _0x5cfc72;
                        _0x4576db[_0x15fe89(0x2dc)](_0x1f063e, _0x401066['toString']());
                    }), _0x20cf00['on'](_0x4b4921['uBDim'], _0x2127c7 => {
                        const _0x780c15 = _0x5cfc72;
                        if (_0x4b4921[_0x780c15(0x38a)] !== _0x780c15(0x39f)) _0x4b4921['WlTuS'](_0x2127c7, 0x0) && _0x4b4921[_0x780c15(0x1b0)](_0x1f063e, _0x780c15(0x148) + _0x2127c7);
                        else {
                            const _0xcaa053 = {};
                            _0xcaa053[_0x780c15(0x213)] = _0x28b42b, _0xcaa053['l'] = _0x255873, _0xcaa053[_0x780c15(0x30a)] = _0x1ac613, _0xcaa053[_0x780c15(0x150)] = _0x23cbd1, _0xcaa053[_0x780c15(0x28e)] = _0x23c443, _0xcaa053['command'] = _0x4b3f57, _0xcaa053[_0x780c15(0x380)] = _0x9351fc, _0xcaa053['q'] = _0x4ba37e, _0xcaa053[_0x780c15(0x161)] = _0x4d63a9, _0xcaa053[_0x780c15(0x1f1)] = _0x2bb6cf, _0xcaa053[_0x780c15(0x25d)] = _0x1e8c3d, _0xcaa053[_0x780c15(0x240)] = _0x5af547, _0xcaa053[_0x780c15(0x1bf)] = _0x46ee13, _0xcaa053[_0x780c15(0x1b8)] = _0x367f33, _0xcaa053[_0x780c15(0x19e)] = _0x179b96, _0xcaa053[_0x780c15(0x305)] = _0x32a153, _0xcaa053[_0x780c15(0x1eb)] = _0x87d778, _0xcaa053[_0x780c15(0x18a)] = _0x3a586a, _0xcaa053[_0x780c15(0x1e2)] = _0x435d68, _0xcaa053['groupName'] = _0x4a7a44, _0xcaa053[_0x780c15(0x13c)] = _0x4d9380, _0xcaa053[_0x780c15(0x24f)] = _0x3f853d, _0xcaa053['isBotAdmins'] = _0x32b24c, _0xcaa053[_0x780c15(0x12f)] = _0x10e95f, _0xcaa053['reply'] = _0x3efc8e, _0x4c806e[_0x780c15(0x28f)](_0x4f1b47, _0x242b4e, _0x853d75, _0xcaa053);
                        }
                    });
                } catch (_0xa32f65) {
                    _0x4b4921[_0x5cfc72(0x31e)](_0x1f063e, util[_0x5cfc72(0x1fa)](_0xa32f65));
                }
                return;
            } else try {
                throw {
                    'json': _0x3aef60[_0x5cfc72(0x26e)](_0x200b4d[_0x5cfc72(0x372)]())
                };
            } catch (_0x5d2a09) {
                if (_0x5d2a09[_0x5cfc72(0x1b7)]) throw _0x5d2a09[_0x5cfc72(0x1b7)];
            }
        }
        if (!_0x127cf5 && _0x4b4921[_0x5cfc72(0x11c)](config[_0x5cfc72(0x2b2)], _0x5cfc72(0x21e))) {
            const _0x4b616f = ['🌼', '❤️', '💐', '🔥', _0x5cfc72(0x308), '❄️', '🧊', '🐳', '💥', '🥀', _0x4b4921[_0x5cfc72(0x2cf)], '🥹', '😩', '🫣', '🤭', '👻', '👾', '🫶', '😻', '🙌', '🫂', '🫀', _0x4b4921[_0x5cfc72(0x312)], _0x4b4921[_0x5cfc72(0x158)], _0x4b4921[_0x5cfc72(0x12e)], _0x5cfc72(0x1c4), '🧕', '👩‍🏫', _0x4b4921[_0x5cfc72(0x373)], _0x4b4921['YgTnJ'], _0x4b4921['iSSIe'], _0x4b4921[_0x5cfc72(0x1d1)], '🧟', _0x4b4921['rhRCx'], '🧞', _0x4b4921[_0x5cfc72(0x295)], _0x4b4921[_0x5cfc72(0x22f)], _0x4b4921[_0x5cfc72(0x123)], _0x4b4921[_0x5cfc72(0x21a)], _0x5cfc72(0x1a5), '🤷', _0x4b4921[_0x5cfc72(0x18c)], '🤦', _0x4b4921[_0x5cfc72(0x32b)], _0x4b4921['cefMY'], '💇', '💃', _0x4b4921['GiwvD'], '🚶', '🧶', '🧤', '👑', '💍', '👝', '💼', '🎒', '🥽', '🐻', '🐼', '🐭', '🐣', '🪿', '🦆', '🦊', '🦋', '🦄', '🪼', '🐋', '🐳', '🦈', '🐍', _0x4b4921['OITIR'], '🦦', '🦚', '🌱', '🍃', '🎍', '🌿', '☘️', '🍀', '🍁', '🪺', '🍄', _0x4b4921[_0x5cfc72(0x2ad)], '🪸', '🪨', '🌺', '🪷', '🪻', '🥀', '🌹', '🌷', '💐', '🌾', '🌸', '🌼', '🌻', '🌝', '🌚', '🌕', '🌎', '💫', '🔥', '☃️', '❄️', _0x4b4921[_0x5cfc72(0x233)], '🫧', '🍟', '🍫', '🧃', '🧊', '🪀', '🤿', '🏆', '🥇', '🥈', '🥉', _0x4b4921[_0x5cfc72(0x39d)], '🤹', _0x4b4921[_0x5cfc72(0x37d)], '🎧', '🎤', '🥁', '🧩', '🎯', '🚀', '🚁', '🗿', _0x4b4921[_0x5cfc72(0x1e6)], '⌛', '⏳', '💸', '💎', '⚙️', '⛓️', '🔪', '🧸', '🎀', '🪄', '🎈', '🎁', '🎉', '🏮', '🪩', '📩', '💌', '📤', '📦', '📊', '📈', '📑', '📉', '📂', '🔖', '🧷', '📌', '📝', '🔏', '🔐', '🩷', '❤️', '🧡', '💛', '💚', '🩵', '💙', '💜', '🖤', '🩶', '🤍', '🤎', _0x4b4921[_0x5cfc72(0x2cf)], _0x4b4921[_0x5cfc72(0x2fd)], '💗', '💖', '💘', '💝', '❌', '✅', '🔰', '〽️', '🌐', '🌀', '⤴️', '⤵️', '🔴', '🟢', '🟡', '🟠', '🔵', '🟣', '⚫', '⚪', '🟤', '🔇', '🔊', '📢', '🔕', '♥️', '🕐', '🚩', _0x4b4921[_0x5cfc72(0x17f)]],
                _0x2d8883 = _0x4b616f[Math['floor'](_0x4b4921[_0x5cfc72(0x32c)](Math[_0x5cfc72(0x253)](), _0x4b616f[_0x5cfc72(0x1fc)]))];
            _0x2f7b70[_0x5cfc72(0x364)](_0x2d8883);
        }
        if (!_0x127cf5 && _0x4b4921[_0x5cfc72(0x1b5)](config[_0x5cfc72(0x14a)], _0x4b4921[_0x5cfc72(0x235)])) {
            const _0x4f94cb = (config[_0x5cfc72(0x343)] || _0x4b4921['UXeiC'])['split'](','),
                _0x37bfba = _0x4f94cb[Math[_0x5cfc72(0x2c5)](_0x4b4921['yTVOo'](Math[_0x5cfc72(0x253)](), _0x4f94cb[_0x5cfc72(0x1fc)]))];
            _0x2f7b70[_0x5cfc72(0x364)](_0x37bfba);
        }
        const _0x3336b9 = JSON[_0x5cfc72(0x26e)](fs[_0x5cfc72(0x154)](_0x4b4921['SDKlV'], _0x4b4921[_0x5cfc72(0x304)])),
            _0xd4b762 = _0x3336b9[_0x5cfc72(0x13e)](_0x3b42df);
        if (_0xd4b762) return;
        const _0x555366 = JSON['parse'](fs[_0x5cfc72(0x154)]('./lib/sudo.json', _0x5cfc72(0x30c))),
            _0x1f6765 = config[_0x5cfc72(0x27c)] + _0x5cfc72(0x260),
            _0x363559 = _0x555366[_0x5cfc72(0x13e)](_0x3b42df),
            _0x51083f = _0x4b4921[_0x5cfc72(0x174)](_0x3b42df, _0x1f6765) || _0x21e557 || _0x363559;
        if (!_0x51083f && _0x4b4921[_0x5cfc72(0x165)](config[_0x5cfc72(0x14b)], _0x4b4921['ADpqa'])) return;
        if (!_0x51083f && _0x4b49e5 && _0x4b4921['hSsXx'](config['MODE'], _0x4b4921[_0x5cfc72(0x18d)])) return;
        if (_0x4b4921[_0x5cfc72(0x2a0)](!_0x51083f, !_0x4b49e5) && _0x4b4921[_0x5cfc72(0x11c)](config[_0x5cfc72(0x14b)], _0x5cfc72(0x309))) return;
        if (_0x4b4921[_0x5cfc72(0x2a0)](_0x4b49e5, _0x3b42df)) {
            if (_0x4b4921['SpHzQ'](_0x4b4921[_0x5cfc72(0x1c5)], _0x4b4921['oXGor'])) try {
                const {
                    logActivity: _0x57da03
                } = _0x4b4921[_0x5cfc72(0x355)](require, _0x4b4921[_0x5cfc72(0x198)]);
                _0x4b4921[_0x5cfc72(0x392)](_0x57da03, _0x3b42df);
            } catch (_0x4526c7) {
                if (_0x4b4921[_0x5cfc72(0x222)](_0x4b4921[_0x5cfc72(0x1cf)], _0x4b4921[_0x5cfc72(0x1cf)])) console[_0x5cfc72(0x264)](_0x4b4921['mFTMY'], _0x4526c7);
                else {
                    const _0x3f823d = {};
                    _0x3f823d['from'] = _0x2544a3, _0x3f823d['l'] = _0x196e44, _0x3f823d[_0x5cfc72(0x30a)] = _0x4960a8, _0x3f823d[_0x5cfc72(0x150)] = _0x7b5e14, _0x3f823d[_0x5cfc72(0x28e)] = _0x2696e7, _0x3f823d[_0x5cfc72(0x2e5)] = _0x42b677, _0x3f823d['args'] = _0x498727, _0x3f823d['q'] = _0x28550b, _0x3f823d[_0x5cfc72(0x161)] = _0x489c9d, _0x3f823d['isGroup'] = _0x5ac07a, _0x3f823d[_0x5cfc72(0x25d)] = _0x430166, _0x3f823d[_0x5cfc72(0x240)] = _0x31d8c5, _0x3f823d['botNumber2'] = _0x599397, _0x3f823d[_0x5cfc72(0x1b8)] = _0x16ec84, _0x3f823d['pushname'] = _0x295be1, _0x3f823d['isMe'] = _0xc35f61, _0x3f823d[_0x5cfc72(0x1eb)] = _0x1b1013, _0x3f823d['isCreator'] = _0x2e6e8d, _0x3f823d['groupMetadata'] = _0x28cff9, _0x3f823d[_0x5cfc72(0x29e)] = _0x1ce358, _0x3f823d[_0x5cfc72(0x13c)] = _0x23095a, _0x3f823d['groupAdmins'] = _0x31031f, _0x3f823d[_0x5cfc72(0x199)] = _0x3ef691, _0x3f823d[_0x5cfc72(0x12f)] = _0x39ce32, _0x3f823d[_0x5cfc72(0x17a)] = _0x4d2181, _0x36e888[_0x5cfc72(0x28f)](_0x147008, _0x5be94c, _0x4dab38, _0x3f823d);
                }
            } else try {
                switch (_0x337c65) {
                case _0x4b4921[_0x5cfc72(0x1bd)]:
                    return _0xd735eb[_0x5cfc72(0x1ac)][_0x5cfc72(0x294)];
                case _0x4b4921[_0x5cfc72(0x37a)]:
                    return _0x292a89[_0x5cfc72(0x1ac)]['extendedTextMessage']['text'];
                case _0x4b4921[_0x5cfc72(0x20e)]:
                    return _0x542556['message'][_0x5cfc72(0x17b)][_0x5cfc72(0x281)] || '';
                case _0x5cfc72(0x1f0):
                    return _0x2558ed['message']['videoMessage'][_0x5cfc72(0x281)] || '';
                case _0x4b4921['vnLAf']:
                    return _0x31e6be[_0x5cfc72(0x1ac)]['documentMessage']['caption'] || '';
                case _0x4b4921[_0x5cfc72(0x397)]:
                    return _0x3e8ab3[_0x5cfc72(0x1ac)]['buttonsResponseMessage']['selectedButtonId'] || '';
                case _0x4b4921[_0x5cfc72(0x1c6)]:
                    return _0x38a4fe[_0x5cfc72(0x1ac)][_0x5cfc72(0x234)][_0x5cfc72(0x226)]['selectedRowId'] || '';
                case _0x5cfc72(0x29d):
                    return _0x473e6d[_0x5cfc72(0x1ac)][_0x5cfc72(0x29d)][_0x5cfc72(0x2bd)] || '';
                default:
                    return '';
                }
            } catch {
                return '';
            }
        }
        const _0x537b24 = _0x4b4921['xkJYo'](require, _0x4b4921[_0x5cfc72(0x2fa)]),
            _0x52a250 = _0x48f50d ? _0x364cda[_0x5cfc72(0x388)](0x1)[_0x5cfc72(0x223)]()['split'](' ')[0x0][_0x5cfc72(0x31d)]() : ![];
        if (_0x48f50d) {
            const _0x10294f = _0x537b24[_0x5cfc72(0x32d)][_0x5cfc72(0x300)](_0x4c0205 => _0x4c0205[_0x5cfc72(0x16d)] === _0x52a250) || _0x537b24[_0x5cfc72(0x32d)][_0x5cfc72(0x300)](_0x4eabd3 => _0x4eabd3['alias'] && _0x4eabd3[_0x5cfc72(0x265)]['includes'](_0x52a250));
            if (_0x10294f) {
                if (_0x4b4921[_0x5cfc72(0x252)](_0x5cfc72(0x147), _0x4b4921[_0x5cfc72(0x345)])) {
                    if (_0x10294f[_0x5cfc72(0x364)]) conn[_0x5cfc72(0x2bb)](_0x1f679e, {
                        'react': {
                            'text': _0x10294f[_0x5cfc72(0x364)],
                            'key': _0x42fc9e[_0x5cfc72(0x358)]
                        }
                    });
                    try {
                        if (_0x4b4921[_0x5cfc72(0x1df)] !== _0x4b4921[_0x5cfc72(0x227)]) {
                            const _0x41c686 = {};
                            _0x41c686[_0x5cfc72(0x213)] = _0x1f679e, _0x41c686[_0x5cfc72(0x30a)] = _0x21d9b5, _0x41c686[_0x5cfc72(0x150)] = _0x364cda, _0x41c686[_0x5cfc72(0x28e)] = _0x48f50d, _0x41c686[_0x5cfc72(0x2e5)] = _0x23df95, _0x41c686[_0x5cfc72(0x380)] = _0x37147, _0x41c686['q'] = _0x3c5d45, _0x41c686[_0x5cfc72(0x161)] = _0x4fb55d, _0x41c686[_0x5cfc72(0x1f1)] = _0x4b49e5, _0x41c686[_0x5cfc72(0x25d)] = _0x3b42df, _0x41c686[_0x5cfc72(0x240)] = _0x443929, _0x41c686['botNumber2'] = _0x5ef90f, _0x41c686[_0x5cfc72(0x1b8)] = _0x251283, _0x41c686[_0x5cfc72(0x19e)] = _0x322c18, _0x41c686[_0x5cfc72(0x305)] = _0x21e557, _0x41c686[_0x5cfc72(0x1eb)] = _0x39318a, _0x41c686[_0x5cfc72(0x18a)] = _0x352637, _0x41c686[_0x5cfc72(0x1e2)] = _0x1a3463, _0x41c686['groupName'] = _0xe0388d, _0x41c686['participants'] = _0x598289, _0x41c686['groupAdmins'] = _0x4b7cc5, _0x41c686[_0x5cfc72(0x199)] = _0x3cd7b0, _0x41c686['isAdmins'] = _0x122dca, _0x41c686[_0x5cfc72(0x17a)] = _0x1f063e, _0x10294f[_0x5cfc72(0x28f)](conn, _0x42fc9e, _0x2f7b70, _0x41c686);
                        } else _0x35e21e['readdir'](_0x3e9e4d, (_0x4400a4, _0x2b9a4b) => {
                            const _0x5b0dbc = _0x5cfc72;
                            if (_0x4400a4) throw _0x4400a4;
                            for (const _0x1cd0dc of _0x2b9a4b) {
                                _0x4afc52[_0x5b0dbc(0x243)](_0x3f69ba[_0x5b0dbc(0x200)](_0x22064d, _0x1cd0dc), _0x3035be => {
                                    if (_0x3035be) throw _0x3035be;
                                });
                            }
                        });
                    } catch (_0x5bb6c9) {
                        if (_0x4b4921['SpHzQ'](_0x4b4921['MdWiM'], _0x4b4921['MdWiM'])) console[_0x5cfc72(0x264)](_0x4b4921[_0x5cfc72(0x1bc)] + _0x5bb6c9);
                        else {
                            if (_0x21fb37) throw _0x42ca12;
                        }
                    }
                } else {
                    let _0x3425cf = _0x1e07fe[_0x5cfc72(0x268)](_0x2cb0f7[_0x5cfc72(0x1ac)])[0x0],
                        _0x52e048 = _0x3425cf === _0x4576db[_0x5cfc72(0x348)];
                    _0x52e048 && (_0x3425cf = _0x5ef676[_0x5cfc72(0x268)](_0x37c7fa[_0x5cfc72(0x1ac)]['ephemeralMessage'][_0x5cfc72(0x1ac)])[0x0]);
                    let _0x25948a = _0x52e048 ? _0x24754a[_0x5cfc72(0x1ac)][_0x5cfc72(0x12a)]['message'] : _0x6de4fd[_0x5cfc72(0x1ac)],
                        _0x7f27e7 = _0x25948a[_0x3425cf];
                    if (_0x4576db[_0x5cfc72(0x1ec)](typeof _0x7f27e7, _0x4576db['bXddv'])) _0x25948a[_0x3425cf] = _0x4576db[_0x5cfc72(0x272)](_0x279af8, _0x7f27e7);
                    else {
                        if (_0x7f27e7[_0x5cfc72(0x281)]) _0x7f27e7[_0x5cfc72(0x281)] = _0x311d4a || _0x7f27e7['caption'];
                        else {
                            if (_0x7f27e7[_0x5cfc72(0x161)]) _0x7f27e7[_0x5cfc72(0x161)] = _0xadae3e || _0x7f27e7[_0x5cfc72(0x161)];
                        }
                    }
                    if (typeof _0x7f27e7 !== _0x4576db[_0x5cfc72(0x30e)]) _0x25948a[_0x3425cf] = {
                        ..._0x7f27e7,
                        ..._0x3817a8
                    };
                    if (_0x3555e7[_0x5cfc72(0x358)][_0x5cfc72(0x188)]) _0x272616 = _0x1fc71b[_0x5cfc72(0x358)]['participant'] = _0x708ad1 || _0x3ff695[_0x5cfc72(0x358)][_0x5cfc72(0x188)];
                    else {
                        if (_0x4ab2ff[_0x5cfc72(0x358)]['participant']) _0x195241 = _0x24c036[_0x5cfc72(0x358)][_0x5cfc72(0x188)] = _0x845706 || _0x4ee328['key'][_0x5cfc72(0x188)];
                    }
                    if (_0x528539[_0x5cfc72(0x358)][_0x5cfc72(0x169)]['includes'](_0x4576db['TwrHO'])) _0x3c6984 = _0x2db54c || _0x33b097[_0x5cfc72(0x358)]['remoteJid'];
                    else {
                        if (_0x26c449['key'][_0x5cfc72(0x169)][_0x5cfc72(0x13e)]('@broadcast')) _0x1965b8 = _0x440e3c || _0x130ee4[_0x5cfc72(0x358)][_0x5cfc72(0x169)];
                    }
                    return _0x19539b[_0x5cfc72(0x358)][_0x5cfc72(0x169)] = _0x4e9989, _0x19e20e[_0x5cfc72(0x358)][_0x5cfc72(0x166)] = _0x4576db[_0x5cfc72(0x2e2)](_0x31e383, _0x4c7b00[_0x5cfc72(0x16f)]['id']), _0x52a3e2[_0x5cfc72(0x297)][_0x5cfc72(0x33e)](_0x218e70);
                }
            }
        }
        _0x537b24[_0x5cfc72(0x32d)][_0x5cfc72(0x37f)](async _0x46ff3b => {
            const _0x59965d = _0x5cfc72;
            if (_0x364cda && _0x46ff3b['on'] === _0x4576db['xoiin']) _0x46ff3b[_0x59965d(0x28f)](conn, _0x42fc9e, _0x2f7b70, {
                'from': _0x1f679e,
                'l': l,
                'quoted': _0x21d9b5,
                'body': _0x364cda,
                'isCmd': _0x48f50d,
                'command': _0x46ff3b,
                'args': _0x37147,
                'q': _0x3c5d45,
                'text': _0x4fb55d,
                'isGroup': _0x4b49e5,
                'sender': _0x3b42df,
                'senderNumber': _0x443929,
                'botNumber2': _0x5ef90f,
                'botNumber': _0x251283,
                'pushname': _0x322c18,
                'isMe': _0x21e557,
                'isOwner': _0x39318a,
                'isCreator': _0x352637,
                'groupMetadata': _0x1a3463,
                'groupName': _0xe0388d,
                'participants': _0x598289,
                'groupAdmins': _0x4b7cc5,
                'isBotAdmins': _0x3cd7b0,
                'isAdmins': _0x122dca,
                'reply': _0x1f063e
            });
            else {
                if (_0x42fc9e['q'] && _0x4576db[_0x59965d(0x2e2)](_0x46ff3b['on'], _0x4576db[_0x59965d(0x1f7)])) _0x46ff3b[_0x59965d(0x28f)](conn, _0x42fc9e, _0x2f7b70, {
                    'from': _0x1f679e,
                    'l': l,
                    'quoted': _0x21d9b5,
                    'body': _0x364cda,
                    'isCmd': _0x48f50d,
                    'command': _0x46ff3b,
                    'args': _0x37147,
                    'q': _0x3c5d45,
                    'text': _0x4fb55d,
                    'isGroup': _0x4b49e5,
                    'sender': _0x3b42df,
                    'senderNumber': _0x443929,
                    'botNumber2': _0x5ef90f,
                    'botNumber': _0x251283,
                    'pushname': _0x322c18,
                    'isMe': _0x21e557,
                    'isOwner': _0x39318a,
                    'isCreator': _0x352637,
                    'groupMetadata': _0x1a3463,
                    'groupName': _0xe0388d,
                    'participants': _0x598289,
                    'groupAdmins': _0x4b7cc5,
                    'isBotAdmins': _0x3cd7b0,
                    'isAdmins': _0x122dca,
                    'reply': _0x1f063e
                });
                else {
                    if ((_0x4576db['xEoOl'](_0x46ff3b['on'], _0x4576db[_0x59965d(0x2e0)]) || _0x4576db[_0x59965d(0x360)](_0x46ff3b['on'], _0x4576db['wWzSN'])) && _0x4576db[_0x59965d(0x2e2)](_0x42fc9e[_0x59965d(0x248)], _0x4576db[_0x59965d(0x1ad)])) _0x46ff3b[_0x59965d(0x28f)](conn, _0x42fc9e, _0x2f7b70, {
                        'from': _0x1f679e,
                        'l': l,
                        'quoted': _0x21d9b5,
                        'body': _0x364cda,
                        'isCmd': _0x48f50d,
                        'command': _0x46ff3b,
                        'args': _0x37147,
                        'q': _0x3c5d45,
                        'text': _0x4fb55d,
                        'isGroup': _0x4b49e5,
                        'sender': _0x3b42df,
                        'senderNumber': _0x443929,
                        'botNumber2': _0x5ef90f,
                        'botNumber': _0x251283,
                        'pushname': _0x322c18,
                        'isMe': _0x21e557,
                        'isOwner': _0x39318a,
                        'isCreator': _0x352637,
                        'groupMetadata': _0x1a3463,
                        'groupName': _0xe0388d,
                        'participants': _0x598289,
                        'groupAdmins': _0x4b7cc5,
                        'isBotAdmins': _0x3cd7b0,
                        'isAdmins': _0x122dca,
                        'reply': _0x1f063e
                    });
                    else _0x4576db[_0x59965d(0x1ec)](_0x46ff3b['on'], _0x59965d(0x1be)) && _0x4576db[_0x59965d(0x278)](_0x42fc9e['type'], _0x4576db[_0x59965d(0x1ee)]) && _0x46ff3b[_0x59965d(0x28f)](conn, _0x42fc9e, _0x2f7b70, {
                        'from': _0x1f679e,
                        'l': l,
                        'quoted': _0x21d9b5,
                        'body': _0x364cda,
                        'isCmd': _0x48f50d,
                        'command': _0x46ff3b,
                        'args': _0x37147,
                        'q': _0x3c5d45,
                        'text': _0x4fb55d,
                        'isGroup': _0x4b49e5,
                        'sender': _0x3b42df,
                        'senderNumber': _0x443929,
                        'botNumber2': _0x5ef90f,
                        'botNumber': _0x251283,
                        'pushname': _0x322c18,
                        'isMe': _0x21e557,
                        'isOwner': _0x39318a,
                        'isCreator': _0x352637,
                        'groupMetadata': _0x1a3463,
                        'groupName': _0xe0388d,
                        'participants': _0x598289,
                        'groupAdmins': _0x4b7cc5,
                        'isBotAdmins': _0x3cd7b0,
                        'isAdmins': _0x122dca,
                        'reply': _0x1f063e
                    });
                }
            }
        });
    }), conn[_0x565c93(0x176)] = _0x3993f2 => {
        const _0x2a26c6 = _0x565c93;
        if (!_0x3993f2) return _0x3993f2;
        if (/:\d+@/gi [_0x2a26c6(0x2a2)](_0x3993f2)) {
            let _0x1978a6 = _0x4b4921[_0x2a26c6(0x26f)](jidDecode, _0x3993f2) || {};
            return _0x1978a6['user'] && _0x1978a6[_0x2a26c6(0x314)] && _0x4b4921['PRXkY'](_0x4b4921[_0x2a26c6(0x2f9)](_0x1978a6['user'], '@'), _0x1978a6[_0x2a26c6(0x314)]) || _0x3993f2;
        } else return _0x3993f2;
    }, conn[_0x565c93(0x214)] = async (_0x2402f9, _0x2d5672, _0xaaeef0 = ![], _0x1671b9 = {}) => {
        const _0x5eba89 = _0x565c93;
        let _0x368ed9;
        if (_0x1671b9[_0x5eba89(0x33d)]) {
            if (_0x5eba89(0x142) !== _0x5eba89(0x142)) {
                if (_0x3580f2[_0x5eba89(0x1b7)]) throw _0x46ac78[_0x5eba89(0x1b7)];
            } else {
                const _0x22c548 = _0x4b4921[_0x5eba89(0x2a8)]['split']('|');
                let _0x2b6373 = 0x0;
                while (!![]) {
                    switch (_0x22c548[_0x2b6373++]) {
                    case '0':
                        _0x2d5672[_0x5eba89(0x1ac)] = _0x2d5672[_0x5eba89(0x1ac)] && _0x2d5672['message'][_0x5eba89(0x12a)] && _0x2d5672[_0x5eba89(0x1ac)][_0x5eba89(0x12a)][_0x5eba89(0x1ac)] ? _0x2d5672[_0x5eba89(0x1ac)][_0x5eba89(0x12a)]['message'] : _0x2d5672[_0x5eba89(0x1ac)] || undefined;
                        continue;
                    case '1':
                        _0x368ed9 = Object[_0x5eba89(0x268)](_0x2d5672[_0x5eba89(0x1ac)][_0x5eba89(0x370)][_0x5eba89(0x1ac)])[0x0];
                        continue;
                    case '2':
                        delete(_0x2d5672['message'] && _0x2d5672[_0x5eba89(0x1ac)]['ignore'] ? _0x2d5672[_0x5eba89(0x1ac)]['ignore'] : _0x2d5672[_0x5eba89(0x1ac)] || undefined);
                        continue;
                    case '3':
                        _0x2d5672[_0x5eba89(0x1ac)] = {
                            ..._0x2d5672[_0x5eba89(0x1ac)][_0x5eba89(0x370)]['message']
                        };
                        continue;
                    case '4':
                        delete _0x2d5672[_0x5eba89(0x1ac)][_0x5eba89(0x370)][_0x5eba89(0x1ac)][_0x368ed9][_0x5eba89(0x293)];
                        continue;
                    }
                    break;
                }
            }
        }
        let _0x1d082c = Object[_0x5eba89(0x268)](_0x2d5672[_0x5eba89(0x1ac)])[0x0],
            _0xb60f5b = await _0x4b4921['xzaeb'](generateForwardMessageContent, _0x2d5672, _0xaaeef0),
            _0x5787b4 = Object['keys'](_0xb60f5b)[0x0],
            _0x5840b1 = {};
        if (_0x4b4921[_0x5eba89(0x387)](_0x1d082c, _0x4b4921[_0x5eba89(0x1bd)])) _0x5840b1 = _0x2d5672[_0x5eba89(0x1ac)][_0x1d082c][_0x5eba89(0x141)];
        _0xb60f5b[_0x5787b4][_0x5eba89(0x141)] = {
            ..._0x5840b1,
            ..._0xb60f5b[_0x5787b4]['contextInfo']
        };
        const _0x3cbd3d = await generateWAMessageFromContent(_0x2402f9, _0xb60f5b, _0x1671b9 ? {
            ..._0xb60f5b[_0x5787b4],
            ..._0x1671b9,
            ..._0x1671b9[_0x5eba89(0x141)] ? {
                'contextInfo': {
                    ..._0xb60f5b[_0x5787b4][_0x5eba89(0x141)],
                    ..._0x1671b9[_0x5eba89(0x141)]
                }
            } : {}
        } : {});
        return await conn[_0x5eba89(0x34d)](_0x2402f9, _0x3cbd3d['message'], {
            'messageId': _0x3cbd3d[_0x5eba89(0x358)]['id']
        }), _0x3cbd3d;
    }, conn[_0x565c93(0x2f2)] = async (_0x41e806, _0x56ecc8, _0xa590fe = !![]) => {
        const _0x228938 = _0x565c93,
            _0x1fc97e = {
                'oENDc': function (_0x21ad2f, _0x2e34a6) {
                    const _0x35d1e6 = _0x4fdc;
                    return _0x4b4921[_0x35d1e6(0x189)](_0x21ad2f, _0x2e34a6);
                },
                'sxKWX': _0x228938(0x2d4)
            };
        if (_0x4b4921[_0x228938(0x36b)](_0x4b4921[_0x228938(0x1c9)], _0x228938(0x249))) {
            let _0x55ec35 = _0x41e806[_0x228938(0x21b)] ? _0x41e806['msg'] : _0x41e806,
                _0x1f30e6 = (_0x41e806[_0x228938(0x21b)] || _0x41e806)[_0x228938(0x196)] || '',
                _0x702be4 = _0x41e806[_0x228938(0x242)] ? _0x41e806[_0x228938(0x242)][_0x228938(0x2d5)](/Message/gi, '') : _0x1f30e6[_0x228938(0x30b)]('/')[0x0];
            const _0x4909d4 = await _0x4b4921[_0x228938(0x186)](downloadContentFromMessage, _0x55ec35, _0x702be4);
            let _0x1cf56e = Buffer[_0x228938(0x213)]([]);
            for await (const _0x6e5298 of _0x4909d4) {
                _0x1cf56e = Buffer[_0x228938(0x126)]([_0x1cf56e, _0x6e5298]);
            }
            let _0x26a935 = await FileType[_0x228938(0x255)](_0x1cf56e);
            return trueFileName = _0xa590fe ? _0x4b4921[_0x228938(0x244)](_0x56ecc8 + '.', _0x26a935[_0x228938(0x1fd)]) : _0x56ecc8, await fs[_0x228938(0x170)](trueFileName, _0x1cf56e), trueFileName;
        } else try {
            const {
                logActivity: _0x3d4fc3
            } = _0x1fc97e[_0x228938(0x210)](_0x3d5133, './lib/activityTracker');
            _0x3d4fc3(_0x201b65);
        } catch (_0x3b3a4d) {
            _0x3effee[_0x228938(0x264)](_0x1fc97e['sxKWX'], _0x3b3a4d);
        }
    }, conn[_0x565c93(0x131)] = async _0x429dfe => {
        const _0x5e85a0 = _0x565c93;
        if (_0x4b4921[_0x5e85a0(0x190)](_0x4b4921[_0x5e85a0(0x339)], _0x4b4921[_0x5e85a0(0x339)])) _0x4b4921[_0x5e85a0(0x382)](_0x347dd4);
        else {
            let _0x9e085b = (_0x429dfe[_0x5e85a0(0x21b)] || _0x429dfe)['mimetype'] || '',
                _0x7d930b = _0x429dfe['mtype'] ? _0x429dfe[_0x5e85a0(0x242)]['replace'](/Message/gi, '') : _0x9e085b[_0x5e85a0(0x30b)]('/')[0x0];
            const _0xd19c6f = await downloadContentFromMessage(_0x429dfe, _0x7d930b);
            let _0x1edc30 = Buffer[_0x5e85a0(0x213)]([]);
            for await (const _0x5b2aee of _0xd19c6f) {
                _0x1edc30 = Buffer[_0x5e85a0(0x126)]([_0x1edc30, _0x5b2aee]);
            }
            return _0x1edc30;
        }
    }, conn[_0x565c93(0x24e)] = async (_0x2c01bb, _0x54d3ca, _0xe8994d, _0x40af0d, _0x223533 = {}) => {
        const _0x56e861 = _0x565c93;
        let _0x1dd058 = '',
            _0x3488f0 = await axios[_0x56e861(0x1b6)](_0x54d3ca);
        _0x1dd058 = _0x3488f0['headers'][_0x56e861(0x130)];
        if (_0x4b4921['ueTop'](_0x1dd058['split']('/')[0x1], _0x4b4921['zUvfP'])) {
            if (_0x4b4921[_0x56e861(0x1b2)] !== _0x4b4921['rHexC']) QrLJVg[_0x56e861(0x382)](_0x594dc9);
            else return conn[_0x56e861(0x2bb)](_0x2c01bb, {
                'video': await getBuffer(_0x54d3ca),
                'caption': _0xe8994d,
                'gifPlayback': !![],
                ..._0x223533
            }, {
                'quoted': _0x40af0d,
                ..._0x223533
            });
        }
        let _0x288711 = _0x1dd058[_0x56e861(0x30b)]('/')[0x0] + _0x4b4921[_0x56e861(0x1e5)];
        if (_0x4b4921[_0x56e861(0x2d9)](_0x1dd058, _0x4b4921[_0x56e861(0x2e4)])) return conn[_0x56e861(0x2bb)](_0x2c01bb, {
            'document': await getBuffer(_0x54d3ca),
            'mimetype': _0x4b4921[_0x56e861(0x2e4)],
            'caption': _0xe8994d,
            ..._0x223533
        }, {
            'quoted': _0x40af0d,
            ..._0x223533
        });
        if (_0x4b4921['fexaQ'](_0x1dd058[_0x56e861(0x30b)]('/')[0x0], _0x4b4921[_0x56e861(0x228)])) return conn['sendMessage'](_0x2c01bb, {
            'image': await _0x4b4921['gkVuA'](getBuffer, _0x54d3ca),
            'caption': _0xe8994d,
            ..._0x223533
        }, {
            'quoted': _0x40af0d,
            ..._0x223533
        });
        if (_0x1dd058[_0x56e861(0x30b)]('/')[0x0] === _0x4b4921[_0x56e861(0x2de)]) return conn['sendMessage'](_0x2c01bb, {
            'video': await _0x4b4921['hGJgS'](getBuffer, _0x54d3ca),
            'caption': _0xe8994d,
            'mimetype': _0x56e861(0x273),
            ..._0x223533
        }, {
            'quoted': _0x40af0d,
            ..._0x223533
        });
        if (_0x4b4921[_0x56e861(0x38b)](_0x1dd058['split']('/')[0x0], 'audio')) return conn[_0x56e861(0x2bb)](_0x2c01bb, {
            'audio': await _0x4b4921['Vrizr'](getBuffer, _0x54d3ca),
            'caption': _0xe8994d,
            'mimetype': _0x4b4921['aFTeE'],
            ..._0x223533
        }, {
            'quoted': _0x40af0d,
            ..._0x223533
        });
    }, conn[_0x565c93(0x36e)] = (_0x4a9a3e, _0x422b9f, _0x43c7a2 = '', _0x4bbff2 = conn[_0x565c93(0x16f)]['id'], _0x58cc05 = {}) => {
        const _0x5e96a1 = _0x565c93;
        let _0xd45a9a = Object[_0x5e96a1(0x268)](_0x422b9f[_0x5e96a1(0x1ac)])[0x0],
            _0x263714 = _0x4b4921[_0x5e96a1(0x18e)](_0xd45a9a, _0x5e96a1(0x12a));
        if (_0x263714) {
            if (_0x4b4921[_0x5e96a1(0x1b5)](_0x5e96a1(0x208), _0x4b4921[_0x5e96a1(0x39a)])) _0xd45a9a = Object[_0x5e96a1(0x268)](_0x422b9f[_0x5e96a1(0x1ac)][_0x5e96a1(0x12a)]['message'])[0x0];
            else {
                if (_0x208d4e) {
                    const _0x5c660e = _0xdfe08d[_0x5e96a1(0x320)](_0x462bb5, arguments);
                    return _0x401f09 = null, _0x5c660e;
                }
            }
        }
        let _0xe0cdd8 = _0x263714 ? _0x422b9f['message'][_0x5e96a1(0x12a)][_0x5e96a1(0x1ac)] : _0x422b9f[_0x5e96a1(0x1ac)],
            _0x249fc3 = _0xe0cdd8[_0xd45a9a];
        if (_0x4b4921[_0x5e96a1(0x17c)](typeof _0x249fc3, _0x4b4921['NyLMw'])) _0xe0cdd8[_0xd45a9a] = _0x4b4921[_0x5e96a1(0x336)](_0x43c7a2, _0x249fc3);
        else {
            if (_0x249fc3[_0x5e96a1(0x281)]) _0x249fc3['caption'] = _0x43c7a2 || _0x249fc3[_0x5e96a1(0x281)];
            else {
                if (_0x249fc3[_0x5e96a1(0x161)]) _0x249fc3[_0x5e96a1(0x161)] = _0x43c7a2 || _0x249fc3[_0x5e96a1(0x161)];
            }
        }
        if (_0x4b4921[_0x5e96a1(0x2fe)](typeof _0x249fc3, _0x5e96a1(0x15d))) _0xe0cdd8[_0xd45a9a] = {
            ..._0x249fc3,
            ..._0x58cc05
        };
        if (_0x422b9f[_0x5e96a1(0x358)][_0x5e96a1(0x188)]) _0x4bbff2 = _0x422b9f[_0x5e96a1(0x358)][_0x5e96a1(0x188)] = _0x4bbff2 || _0x422b9f[_0x5e96a1(0x358)][_0x5e96a1(0x188)];
        else {
            if (_0x422b9f[_0x5e96a1(0x358)][_0x5e96a1(0x188)]) _0x4bbff2 = _0x422b9f[_0x5e96a1(0x358)]['participant'] = _0x4bbff2 || _0x422b9f[_0x5e96a1(0x358)][_0x5e96a1(0x188)];
        }
        if (_0x422b9f['key']['remoteJid'][_0x5e96a1(0x13e)](_0x4b4921[_0x5e96a1(0x1f3)])) _0x4bbff2 = _0x4bbff2 || _0x422b9f['key'][_0x5e96a1(0x169)];
        else {
            if (_0x422b9f['key'][_0x5e96a1(0x169)][_0x5e96a1(0x13e)](_0x5e96a1(0x247))) _0x4bbff2 = _0x4bbff2 || _0x422b9f[_0x5e96a1(0x358)]['remoteJid'];
        }
        return _0x422b9f['key']['remoteJid'] = _0x4a9a3e, _0x422b9f[_0x5e96a1(0x358)][_0x5e96a1(0x166)] = _0x4bbff2 === conn[_0x5e96a1(0x16f)]['id'], proto[_0x5e96a1(0x297)][_0x5e96a1(0x33e)](_0x422b9f);
    }, conn[_0x565c93(0x2b5)] = async (_0xe55e7c, _0x14303c) => {
        const _0x15a236 = _0x565c93;
        let _0x5a6886, _0x16c5a9 = Buffer[_0x15a236(0x351)](_0xe55e7c) ? _0xe55e7c : /^data:.*?\/.*?;base64,/i [_0x15a236(0x2a2)](_0xe55e7c) ? Buffer[_0x15a236(0x213)](_0xe55e7c[_0x15a236(0x30b)]
            `,` [0x1], _0x4b4921[_0x15a236(0x33a)]) : /^https?:\/\// [_0x15a236(0x2a2)](_0xe55e7c) ? await (_0x5a6886 = await getBuffer(_0xe55e7c)) : fs['existsSync'](_0xe55e7c) ? (_0xe75038 = _0xe55e7c, fs[_0x15a236(0x154)](_0xe55e7c)) : _0x4b4921[_0x15a236(0x2d9)](typeof _0xe55e7c, _0x4b4921[_0x15a236(0x298)]) ? _0xe55e7c : Buffer[_0x15a236(0x229)](0x0);
        const _0x84854 = {};
        _0x84854['mime'] = _0x4b4921[_0x15a236(0x311)], _0x84854[_0x15a236(0x1fd)] = _0x4b4921[_0x15a236(0x1de)];
        let _0x4ff460 = await FileType[_0x15a236(0x255)](_0x16c5a9) || _0x84854,
            _0xe75038 = path[_0x15a236(0x200)](__filename, _0x4b4921[_0x15a236(0x2e9)](_0x4b4921[_0x15a236(0x1ce)](_0x4b4921[_0x15a236(0x1ca)](__dirname, _0x4b4921[_0x15a236(0x32c)](new Date(), 0x1)), '.'), _0x4ff460[_0x15a236(0x1fd)]));
        if (_0x16c5a9 && _0x14303c) fs[_0x15a236(0x195)][_0x15a236(0x122)](_0xe75038, _0x16c5a9);
        return {
            'res': _0x5a6886,
            'filename': _0xe75038,
            'size': await _0x4b4921[_0x15a236(0x393)](getSizeMedia, _0x16c5a9),
            ..._0x4ff460,
            'data': _0x16c5a9
        };
    }, conn['sendFile'] = async (_0x4f65af, _0x60952b, _0x2c8ac6, _0x42935d = {}, _0x509ed9 = {}) => {
        const _0x42231a = _0x565c93,
            _0x5a6da0 = {
                'EVPrl': function (_0x399dc0, _0x9aefef) {
                    const _0x11c03c = _0x4fdc;
                    return _0x4b4921[_0x11c03c(0x329)](_0x399dc0, _0x9aefef);
                },
                'jjgtV': function (_0x19a802, _0x1456ff) {
                    const _0x14d246 = _0x4fdc;
                    return _0x4b4921[_0x14d246(0x285)](_0x19a802, _0x1456ff);
                },
                'xYhRS': _0x4b4921[_0x42231a(0x365)]
            };
        let _0x5320f6 = await conn[_0x42231a(0x2b5)](_0x60952b, !![]),
            {
                filename: _0x545984,
                size: _0xfe50de,
                ext: _0x4e7f36,
                mime: _0x445e95,
                data: _0x3b3016
            } = _0x5320f6,
            _0x3dda3b = '',
            _0x15670b = _0x445e95,
            _0x4aaaaf = _0x545984;
        if (_0x509ed9[_0x42231a(0x349)]) _0x3dda3b = _0x42231a(0x354);
        if (_0x509ed9[_0x42231a(0x245)] || /webp/ [_0x42231a(0x2a2)](_0x445e95)) {
            if (_0x4b4921[_0x42231a(0x1e9)](_0x4b4921[_0x42231a(0x301)], _0x4b4921[_0x42231a(0x301)])) {
                let {
                    writeExif: _0x971305
                } = _0x4b4921[_0x42231a(0x341)](require, _0x4b4921['WLIAY']);
                const _0xc98ee = {};
                _0xc98ee['mimetype'] = _0x445e95, _0xc98ee[_0x42231a(0x1ba)] = _0x3b3016;
                let _0x12657e = _0xc98ee;
                const _0x4f8d6a = {};
                _0x4f8d6a[_0x42231a(0x15e)] = Config[_0x42231a(0x15e)], _0x4f8d6a[_0x42231a(0x36c)] = Config['packname'], _0x4f8d6a['categories'] = _0x509ed9[_0x42231a(0x26a)] ? _0x509ed9[_0x42231a(0x26a)] : [], _0x4aaaaf = await _0x4b4921[_0x42231a(0x25f)](_0x971305, _0x12657e, _0x4f8d6a), await fs[_0x42231a(0x195)]['unlink'](_0x545984), _0x3dda3b = _0x4b4921['bKfHo'], _0x15670b = _0x4b4921[_0x42231a(0x20a)];
            } else _0x5a6da0['EVPrl'](_0xf7931d, _0x5a6da0['jjgtV'](_0x5a6da0[_0x42231a(0x2e8)], _0x27f55c)), _0x24fd2f++;
        } else {
            if (/image/ [_0x42231a(0x2a2)](_0x445e95)) _0x3dda3b = _0x42231a(0x1d9);
            else {
                if (/video/ [_0x42231a(0x2a2)](_0x445e95)) _0x3dda3b = _0x4b4921['CTCcX'];
                else {
                    if (/audio/ [_0x42231a(0x2a2)](_0x445e95)) _0x3dda3b = _0x4b4921[_0x42231a(0x216)];
                    else _0x3dda3b = _0x4b4921['AXCFL'];
                }
            }
        }
        const _0x2a496c = {};
        _0x2a496c[_0x42231a(0x2a3)] = _0x4aaaaf;
        const _0x557a9a = {
                [_0x3dda3b]: _0x2a496c,
                'mimetype': _0x15670b,
                'fileName': _0x2c8ac6,
                ..._0x509ed9
            },
            _0x4784ac = {
                'quoted': _0x42935d,
                ..._0x509ed9
            };
        return await conn[_0x42231a(0x2bb)](_0x4f65af, _0x557a9a, _0x4784ac), fs[_0x42231a(0x195)][_0x42231a(0x243)](_0x4aaaaf);
    }, conn[_0x565c93(0x39b)] = async _0x551d70 => {
        const _0x53017f = _0x565c93;
        return [..._0x551d70[_0x53017f(0x1da)](/@([0-9]{5,16}|0)/g)][_0x53017f(0x37f)](_0x3b3f96 => _0x3b3f96[0x1] + '@s.whatsapp.net');
    }, conn[_0x565c93(0x2a1)] = async (_0x207b72, _0x2049c2, _0x2df6ed = '', _0xd1af45 = '', _0x5cbd7f = '', _0x3a040c = {}) => {
        const _0x385651 = _0x565c93;
        if (_0x4b4921[_0x385651(0x325)](_0x4b4921['ePxlQ'], _0x4b4921[_0x385651(0x140)])) _0x43df20 += _0x385651(0x1d8) + _0x9b59dd[_0x385651(0x1fc)] + _0x385651(0x26b);
        else {
            let _0x2cd06e = await conn[_0x385651(0x2b5)](_0x2049c2, !![]),
                {
                    mime: _0x123ac7,
                    ext: _0x3d1d07,
                    res: _0x312896,
                    data: _0xe5b0cf,
                    filename: _0x10948d
                } = _0x2cd06e;
            if (_0x312896 && _0x4b4921['ORlwH'](_0x312896[_0x385651(0x2a5)], 0xc8) || _0x4b4921[_0x385651(0x23c)](file[_0x385651(0x1fc)], 0x10000)) {
                if (_0x4b4921[_0x385651(0x38d)](_0x385651(0x332), _0x4b4921['teOpj'])) try {
                    throw {
                        'json': JSON['parse'](file[_0x385651(0x372)]())
                    };
                } catch (_0x2ef86c) {
                    if (_0x2ef86c[_0x385651(0x1b7)]) throw _0x2ef86c[_0x385651(0x1b7)];
                } else {
                    _0x4b4921[_0x385651(0x1ea)](_0x2f5af7, 'Provide me with a query to run Master!');
                    return;
                }
            }
            let _0x4603e5 = '',
                _0x209e9e = _0x123ac7,
                _0x12282f = _0x10948d;
            if (_0x3a040c[_0x385651(0x349)]) _0x4603e5 = _0x4b4921[_0x385651(0x2ab)];
            if (_0x3a040c[_0x385651(0x245)] || /webp/ ['test'](_0x123ac7)) {
                let {
                    writeExif: _0x2d22f5
                } = _0x4b4921[_0x385651(0x329)](require, _0x4b4921[_0x385651(0x128)]);
                const _0x549ced = {};
                _0x549ced[_0x385651(0x196)] = _0x123ac7, _0x549ced[_0x385651(0x1ba)] = _0xe5b0cf;
                let _0x454654 = _0x549ced;
                const _0xddc20 = {};
                _0xddc20[_0x385651(0x15e)] = _0x3a040c['packname'] ? _0x3a040c[_0x385651(0x15e)] : Config[_0x385651(0x15e)], _0xddc20[_0x385651(0x36c)] = _0x3a040c[_0x385651(0x36c)] ? _0x3a040c['author'] : Config[_0x385651(0x36c)], _0xddc20[_0x385651(0x26a)] = _0x3a040c['categories'] ? _0x3a040c[_0x385651(0x26a)] : [], _0x12282f = await _0x2d22f5(_0x454654, _0xddc20), await fs[_0x385651(0x195)][_0x385651(0x243)](_0x10948d), _0x4603e5 = _0x4b4921[_0x385651(0x2df)], _0x209e9e = _0x4b4921[_0x385651(0x20a)];
            } else {
                if (/image/ [_0x385651(0x2a2)](_0x123ac7)) _0x4603e5 = _0x4b4921[_0x385651(0x228)];
                else {
                    if (/video/ [_0x385651(0x2a2)](_0x123ac7)) _0x4603e5 = _0x4b4921['CTCcX'];
                    else {
                        if (/audio/ [_0x385651(0x2a2)](_0x123ac7)) _0x4603e5 = _0x4b4921[_0x385651(0x216)];
                        else _0x4603e5 = _0x4b4921[_0x385651(0x2ab)];
                    }
                }
            }
            const _0x2426ea = {};
            _0x2426ea[_0x385651(0x2a3)] = _0x12282f;
            const _0x1babcb = {
                    [_0x4603e5]: _0x2426ea,
                    'caption': _0xd1af45,
                    'mimetype': _0x209e9e,
                    'fileName': _0x2df6ed,
                    ..._0x3a040c
                },
                _0x719536 = {
                    'quoted': _0x5cbd7f,
                    ..._0x3a040c
                };
            return await conn['sendMessage'](_0x207b72, _0x1babcb, _0x719536), fs[_0x385651(0x195)][_0x385651(0x243)](_0x12282f);
        }
    }, conn['sendVideoAsSticker'] = async (_0x517b00, _0x300b98, _0x5559dd = {}) => {
        const _0x5061a3 = _0x565c93;
        if (_0x4b4921[_0x5061a3(0x338)](_0x5061a3(0x19b), _0x5061a3(0x2da))) {
            if (_0x29e557) throw _0x1bea2c;
            for (const _0x99ebc9 of _0x5060e6) {
                _0x1c5bf9[_0x5061a3(0x243)](_0x320fc6[_0x5061a3(0x200)](_0x38daa8, _0x99ebc9), _0xc3da62 => {
                    if (_0xc3da62) throw _0xc3da62;
                });
            }
        } else {
            let _0x500621;
            _0x5559dd && (_0x5559dd[_0x5061a3(0x15e)] || _0x5559dd[_0x5061a3(0x36c)]) ? _0x4b4921[_0x5061a3(0x252)](_0x4b4921[_0x5061a3(0x398)], _0x4b4921['pJmKk']) ? _0x4b4921['oQMYD'](_0x2e4c70, _0x1677cf[_0x5061a3(0x372)]()) : _0x500621 = await _0x4b4921[_0x5061a3(0x1e8)](writeExifVid, _0x300b98, _0x5559dd) : _0x500621 = await videoToWebp(_0x300b98);
            const _0x9395dd = {};
            _0x9395dd[_0x5061a3(0x2a3)] = _0x500621;
            const _0x657b3 = {
                'sticker': _0x9395dd,
                ..._0x5559dd
            };
            await conn['sendMessage'](_0x517b00, _0x657b3, _0x5559dd);
        }
    }, conn[_0x565c93(0x2ea)] = async (_0x9aed51, _0x3b7338, _0x472ffb = {}) => {
        const _0x3b2f07 = _0x565c93;
        let _0x2cfd0c;
        _0x472ffb && (_0x472ffb[_0x3b2f07(0x15e)] || _0x472ffb['author']) ? _0x2cfd0c = await _0x4b4921[_0x3b2f07(0x29b)](writeExifImg, _0x3b7338, _0x472ffb) : _0x4b4921[_0x3b2f07(0x396)] !== _0x4b4921[_0x3b2f07(0x396)] ? _0x2c475b = _0x3423c4['concat']([_0x17e1ee, _0x30a7a7]) : _0x2cfd0c = await _0x4b4921[_0x3b2f07(0x151)](imageToWebp, _0x3b7338);
        const _0x5d803d = {};
        _0x5d803d['url'] = _0x2cfd0c;
        const _0x21a446 = {
            'sticker': _0x5d803d,
            ..._0x472ffb
        };
        await conn[_0x3b2f07(0x2bb)](_0x9aed51, _0x21a446, _0x472ffb);
    }, conn[_0x565c93(0x1f9)] = async (_0xd5a8b3, _0x2b8005, _0x11308d, _0x21304f = {}) => conn[_0x565c93(0x2bb)](_0xd5a8b3, {
        'text': _0x2b8005,
        'contextInfo': {
            'mentionedJid': [..._0x2b8005[_0x565c93(0x1da)](/@(\d{0,16})/g)][_0x565c93(0x37f)](_0x23700b => _0x23700b[0x1] + _0x565c93(0x260))
        },
        ..._0x21304f
    }, {
        'quoted': _0x11308d
    }), conn['sendImage'] = async (_0x11555c, _0x4afde2, _0x203e0c = '', _0x26892b = '', _0x1cbcfd) => {
        const _0x178556 = _0x565c93;
        let _0x5a2337 = Buffer[_0x178556(0x351)](_0x4afde2) ? _0x4afde2 : /^data:.*?\/.*?;base64,/i ['test'](_0x4afde2) ? Buffer[_0x178556(0x213)](_0x4afde2[_0x178556(0x30b)]
            `,` [0x1], _0x4b4921[_0x178556(0x33a)]) : /^https?:\/\// ['test'](_0x4afde2) ? await await _0x4b4921[_0x178556(0x230)](getBuffer, _0x4afde2) : fs[_0x178556(0x2ae)](_0x4afde2) ? fs[_0x178556(0x154)](_0x4afde2) : Buffer[_0x178556(0x229)](0x0);
        const _0x1b2a7d = {
                'image': _0x5a2337,
                'caption': _0x203e0c,
                ..._0x1cbcfd
            },
            _0x292a68 = {};
        return _0x292a68[_0x178556(0x30a)] = _0x26892b, await conn['sendMessage'](_0x11555c, _0x1b2a7d, _0x292a68);
    }, conn[_0x565c93(0x390)] = (_0xa33c5e, _0x495a92, _0x543462 = '', _0x15a61a) => conn[_0x565c93(0x2bb)](_0xa33c5e, {
        'text': _0x495a92,
        ..._0x15a61a
    }, {
        'quoted': _0x543462
    }), conn[_0x565c93(0x2cc)] = (_0x1581d8, _0x223eca = [], _0x36085a, _0x14b67b, _0x354056 = '', _0x5dcc89 = {}) => {
        const _0x291d33 = _0x565c93,
            _0x4ccf85 = {};
        _0x4ccf85[_0x291d33(0x346)] = _0x4b4921[_0x291d33(0x219)], _0x4ccf85[_0x291d33(0x133)] = _0x4b4921['TCoFW'];
        const _0x57b7e2 = _0x4ccf85;
        if (_0x4b4921[_0x291d33(0x321)](_0x4b4921[_0x291d33(0x277)], 'qAJDG')) {
            const _0x12310e = {
                'text': _0x36085a,
                'footer': _0x14b67b,
                'buttons': _0x223eca,
                'headerType': 0x2,
                ..._0x5dcc89
            };
            let _0x54f3b5 = _0x12310e;
            const _0x58b7de = {
                'quoted': _0x354056,
                ..._0x5dcc89
            };
            conn['sendMessage'](_0x1581d8, _0x54f3b5, _0x58b7de);
        } else return function (_0x4cce97) {} [_0x291d33(0x276)](bYibOV[_0x291d33(0x346)])['apply'](bYibOV['ebewR']);
    }, conn[_0x565c93(0x1d4)] = async (_0x369150, _0x238a1d = '', _0x35f9c8 = '', _0x17f1ce, _0x27f8e3 = [], _0x504c8b, _0x56665a = {}) => {
        const _0x17294c = _0x565c93,
            _0x50ad61 = {};
        _0x50ad61['image'] = _0x17f1ce, _0x50ad61['jpegThumbnail'] = _0x504c8b;
        const _0x419025 = {};
        _0x419025[_0x17294c(0x269)] = conn[_0x17294c(0x29f)];
        let _0x223c8a = await _0x4b4921['GPBJu'](prepareWAMessageMedia, _0x50ad61, _0x419025);
        const _0x392b33 = {};
        _0x392b33[_0x17294c(0x17b)] = _0x223c8a['imageMessage'], _0x392b33[_0x17294c(0x1b4)] = _0x238a1d, _0x392b33[_0x17294c(0x337)] = _0x35f9c8, _0x392b33[_0x17294c(0x366)] = _0x27f8e3;
        const _0x4df4ec = {};
        _0x4df4ec[_0x17294c(0x179)] = _0x392b33;
        const _0x4cb500 = {};
        _0x4cb500['templateMessage'] = _0x4df4ec;
        var _0x3a3b41 = _0x4b4921[_0x17294c(0x19a)](generateWAMessageFromContent, _0x369150, proto[_0x17294c(0x160)]['fromObject'](_0x4cb500), _0x56665a);
        conn['relayMessage'](_0x369150, _0x3a3b41[_0x17294c(0x1ac)], {
            'messageId': _0x3a3b41['key']['id']
        });
    }, conn[_0x565c93(0x394)] = (_0x12f5bd, _0x445c29 = ![]) => {
        const _0x2deeaa = _0x565c93;
        id = conn['decodeJid'](_0x12f5bd), _0x445c29 = conn[_0x2deeaa(0x1af)] || _0x445c29;
        let _0x28fe99;
        if (id['endsWith'](_0x4b4921[_0x2deeaa(0x1a2)])) return new Promise(async _0x4e0cee => {
            const _0x92a0a1 = _0x2deeaa;
            _0x28fe99 = store[_0x92a0a1(0x34b)][id] || {};
            if (!(_0x28fe99[_0x92a0a1(0x2e1)][_0x92a0a1(0x378)] || _0x28fe99[_0x92a0a1(0x2cb)])) _0x28fe99 = conn['groupMetadata'](id) || {};
            _0x4b4921[_0x92a0a1(0x355)](_0x4e0cee, _0x28fe99['name'] || _0x28fe99[_0x92a0a1(0x2cb)] || _0x4b4921[_0x92a0a1(0x11d)](PhoneNumber, _0x4b4921[_0x92a0a1(0x236)]('+', id[_0x92a0a1(0x2d5)](_0x4b4921[_0x92a0a1(0x1f3)], '')))[_0x92a0a1(0x32a)](_0x4b4921[_0x92a0a1(0x331)]));
        });
        else _0x28fe99 = _0x4b4921[_0x2deeaa(0x11c)](id, _0x2deeaa(0x389)) ? {
            'id': id,
            'name': _0x4b4921['qkvQO']
        } : _0x4b4921[_0x2deeaa(0x222)](id, conn[_0x2deeaa(0x176)](conn[_0x2deeaa(0x16f)]['id'])) ? conn[_0x2deeaa(0x16f)] : store[_0x2deeaa(0x34b)][id] || {};
        return (_0x445c29 ? '' : _0x28fe99['name']) || _0x28fe99[_0x2deeaa(0x2cb)] || _0x28fe99['verifiedName'] || _0x4b4921[_0x2deeaa(0x31e)](PhoneNumber, _0x4b4921[_0x2deeaa(0x2ac)]('+', _0x12f5bd[_0x2deeaa(0x2d5)](_0x2deeaa(0x260), '')))[_0x2deeaa(0x32a)](_0x4b4921[_0x2deeaa(0x331)]);
    }, conn[_0x565c93(0x20d)] = async (_0x3d2e81, _0x322509, _0x16081b = '', _0x19a4d2 = {}) => {
        const _0x5608bc = _0x565c93;
        if (_0x4b4921[_0x5608bc(0x284)](_0x4b4921[_0x5608bc(0x344)], _0x5608bc(0x350))) {
            let _0x3ed07a = [];
            for (let _0x3ad827 of _0x322509) {
                _0x3ed07a[_0x5608bc(0x215)]({
                    'displayName': await conn[_0x5608bc(0x394)](_0x3ad827 + _0x4b4921[_0x5608bc(0x1f3)]),
                    'vcard': _0x5608bc(0x145) + await conn[_0x5608bc(0x394)](_0x4b4921['Bpxpg'](_0x3ad827, _0x4b4921[_0x5608bc(0x1f3)])) + _0x5608bc(0x1f2) + global[_0x5608bc(0x318)] + '\x0aitem1.TEL;waid=' + _0x3ad827 + ':' + _0x3ad827 + _0x5608bc(0x138) + global[_0x5608bc(0x221)] + _0x5608bc(0x2f8) + global['github'] + '/malvin-xd\x0aitem3.X-ABLabel:GitHub\x0aitem4.ADR:;;' + global[_0x5608bc(0x16e)] + _0x5608bc(0x1cc)
                });
            }
            const _0x1d8bd9 = {};
            _0x1d8bd9['displayName'] = _0x3ed07a['length'] + _0x5608bc(0x155), _0x1d8bd9[_0x5608bc(0x34b)] = _0x3ed07a;
            const _0x378129 = {
                    'contacts': _0x1d8bd9,
                    ..._0x19a4d2
                },
                _0x292f31 = {};
            _0x292f31[_0x5608bc(0x30a)] = _0x16081b, conn[_0x5608bc(0x2bb)](_0x3d2e81, _0x378129, _0x292f31);
        } else _0x3672e5[_0x5608bc(0x264)](_0x4b4921[_0x5608bc(0x211)], _0x1f544c);
    }, conn[_0x565c93(0x1d7)] = _0x2d0a52 => {
        const _0xc689b4 = _0x565c93,
            _0x9936d4 = {};
        return _0x9936d4['to'] = _0x4b4921[_0xc689b4(0x1f3)], _0x9936d4[_0xc689b4(0x248)] = _0x4b4921[_0xc689b4(0x2b8)], _0x9936d4[_0xc689b4(0x209)] = _0x4b4921['ouBpw'], conn[_0xc689b4(0x2db)]({
            'tag': 'iq',
            'attrs': _0x9936d4,
            'content': [{
                'tag': _0x4b4921['ouBpw'],
                'attrs': {},
                'content': Buffer[_0xc689b4(0x213)](_0x2d0a52, _0x4b4921['PYtgn'])
            }]
        }), _0x2d0a52;
    }, conn['serializeM'] = _0x1b5a39 => sms(conn, _0x1b5a39, store);
}
app[_0x1d324b(0x261)]('/', (_0x36930a, _0x3d0bbc) => _0x3d0bbc[_0x1d324b(0x184)](require('path')[_0x1d324b(0x200)](__dirname, _0x1d324b(0x217)))), app[_0x1d324b(0x1a1)](port, () => console[_0x1d324b(0x266)]('Server listening on port http://localhost:' + port)), setTimeout(() => {
    const _0x450611 = _0x1d324b,
        _0xa6488a = {
            'PNjYH': function (_0x5cebf4) {
                return _0x5cebf4();
            }
        };
    _0xa6488a[_0x450611(0x175)](connectToWA);
}, 0xfa0);

function _0x4a35dc(_0x44f6bc) {
    const _0x5914e2 = _0x1d324b,
        _0x2ec9f8 = {
            'fSCfq': function (_0x357add, _0x475503) {
                return _0x357add(_0x475503);
            },
            'FkQsv': function (_0x49180b, _0x5beb75) {
                return _0x49180b + _0x5beb75;
            },
            'HDpUc': function (_0x21f0d0, _0x486cc6) {
                return _0x21f0d0 + _0x486cc6;
            },
            'UGoqc': 'input',
            'xQmiN': function (_0x16d78a, _0x5159c6) {
                return _0x16d78a === _0x5159c6;
            },
            'NRFJK': _0x5914e2(0x1ef),
            'eVyHD': _0x5914e2(0x34f),
            'FYyEU': function (_0x251e67, _0x27a029) {
                return _0x251e67 === _0x27a029;
            },
            'lZkxg': _0x5914e2(0x15d),
            'iJpAh': function (_0x94cc6, _0x28414a) {
                return _0x94cc6 !== _0x28414a;
            },
            'IKxxz': _0x5914e2(0x163),
            'xSgZU': _0x5914e2(0x1a8),
            'HHPVb': _0x5914e2(0x1fc),
            'xMzKM': function (_0x28def2, _0x260350) {
                return _0x28def2 === _0x260350;
            },
            'LyNMn': function (_0x1ac703, _0x40be4a) {
                return _0x1ac703 % _0x40be4a;
            },
            'KiulO': 'debu',
            'RcMbt': _0x5914e2(0x2be),
            'UjTnp': function (_0x2614d4, _0x37f8d8) {
                return _0x2614d4 === _0x37f8d8;
            },
            'JYTxl': 'icmDT',
            'bYdzC': function (_0x2973e3, _0xa106ee) {
                return _0x2973e3 + _0xa106ee;
            },
            'nnWGp': 'gger',
            'tvHrZ': 'stateObject',
            'UYsnl': function (_0x3f09bf, _0x84268c) {
                return _0x3f09bf(_0x84268c);
            },
            'jrIfD': _0x5914e2(0x35d),
            'qquMX': '👩‍🏫',
            'PUoRJ': '👨‍💻',
            'lufTy': _0x5914e2(0x120),
            'ggqHm': _0x5914e2(0x1ff),
            'PnLwy': '🧟‍♀️',
            'kqSXv': _0x5914e2(0x2e6),
            'pgptw': _0x5914e2(0x14e),
            'IuQWp': _0x5914e2(0x352),
            'vMToJ': _0x5914e2(0x254),
            'lKIoi': _0x5914e2(0x259),
            'kpENU': _0x5914e2(0x1a5),
            'XVGOZ': _0x5914e2(0x256),
            'PKbAb': '🤦‍♀️',
            'TZEuS': _0x5914e2(0x1e7),
            'LiduZ': '🚶‍♀️',
            'IYdHf': _0x5914e2(0x1c2),
            'AIivf': _0x5914e2(0x35e),
            'gyTXm': _0x5914e2(0x35c),
            'YVnMs': '❤‍🩹',
            'fBazF': '🇵🇰',
            'yEyQx': function (_0x126b2d, _0x419cbc) {
                return _0x126b2d * _0x419cbc;
            },
            'hHBBe': _0x5914e2(0x280),
            'rTxHG': _0x5914e2(0x381)
        };

    function _0x5d99b2(_0x62e36f) {
        const _0x75d4fd = _0x5914e2,
            _0x6d0967 = {
                'QNAVg': function (_0x315fe6, _0x13ea28) {
                    const _0x847f25 = _0x4fdc;
                    return _0x2ec9f8[_0x847f25(0x2c1)](_0x315fe6, _0x13ea28);
                },
                'NxJIu': function (_0x168611, _0x381700) {
                    const _0x4f113b = _0x4fdc;
                    return _0x2ec9f8[_0x4f113b(0x124)](_0x168611, _0x381700);
                },
                'EfhxW': function (_0x17e0de, _0xf8606) {
                    const _0x40dca4 = _0x4fdc;
                    return _0x2ec9f8[_0x40dca4(0x2e3)](_0x17e0de, _0xf8606);
                },
                'qKfln': _0x75d4fd(0x1bb),
                'LwPcX': _0x2ec9f8[_0x75d4fd(0x241)],
                'ENAQa': function (_0x49623e, _0x297b9f) {
                    return _0x2ec9f8['xQmiN'](_0x49623e, _0x297b9f);
                },
                'sDqrM': _0x2ec9f8[_0x75d4fd(0x36f)],
                'XxlLC': _0x75d4fd(0x1d3),
                'xZJGI': function (_0x134815, _0x1bfe16) {
                    const _0x30cf12 = _0x75d4fd;
                    return _0x2ec9f8[_0x30cf12(0x2e3)](_0x134815, _0x1bfe16);
                }
            };
        if (_0x2ec9f8[_0x75d4fd(0x307)](_0x2ec9f8[_0x75d4fd(0x26d)], _0x2ec9f8['eVyHD'])) {
            if (_0x2ec9f8[_0x75d4fd(0x327)](typeof _0x62e36f, _0x2ec9f8['lZkxg'])) {
                if (_0x2ec9f8['iJpAh']('UhKaJ', _0x2ec9f8[_0x75d4fd(0x197)])) return function (_0x1c2765) {} [_0x75d4fd(0x276)](_0x2ec9f8['xSgZU'])[_0x75d4fd(0x320)](_0x75d4fd(0x1a9));
                else {
                    if (!_0x23181b) return _0x1fc33c;
                    if (/:\d+@/gi [_0x75d4fd(0x2a2)](_0x2396ce)) {
                        let _0x2db71a = _0x6d0967[_0x75d4fd(0x376)](_0x54e630, _0x3812bc) || {};
                        return _0x2db71a[_0x75d4fd(0x16f)] && _0x2db71a[_0x75d4fd(0x314)] && _0x6d0967[_0x75d4fd(0x267)](_0x6d0967[_0x75d4fd(0x29a)](_0x2db71a[_0x75d4fd(0x16f)], '@'), _0x2db71a['server']) || _0x45b3e2;
                    } else return _0x3149ab;
                }
            } else {
                if (_0x2ec9f8['iJpAh'](_0x2ec9f8['HDpUc']('', _0x62e36f / _0x62e36f)[_0x2ec9f8[_0x75d4fd(0x2b3)]], 0x1) || _0x2ec9f8['xMzKM'](_0x2ec9f8[_0x75d4fd(0x2d8)](_0x62e36f, 0x14), 0x0))(function () {
                    return !![];
                } [_0x75d4fd(0x276)](_0x2ec9f8[_0x75d4fd(0x2e3)](_0x2ec9f8['KiulO'], _0x75d4fd(0x386)))[_0x75d4fd(0x24a)](_0x2ec9f8['RcMbt']));
                else {
                    if (_0x2ec9f8['UjTnp'](_0x75d4fd(0x23a), _0x2ec9f8[_0x75d4fd(0x28b)]))(function () {
                        const _0x2259de = _0x75d4fd,
                            _0x16f281 = {
                                'LiPgX': _0x6d0967[_0x2259de(0x2fb)],
                                'kqCPw': _0x2259de(0x359),
                                'tbloF': function (_0x394f9f, _0x5b2621) {
                                    const _0x491661 = _0x2259de;
                                    return _0x6d0967[_0x491661(0x29a)](_0x394f9f, _0x5b2621);
                                },
                                'OLuvr': _0x6d0967[_0x2259de(0x2ff)],
                                'tngym': function (_0x29eeb9, _0x1e1d60, _0x49f22f) {
                                    return _0x29eeb9(_0x1e1d60, _0x49f22f);
                                }
                            };
                        if (_0x6d0967[_0x2259de(0x1aa)](_0x6d0967[_0x2259de(0x14c)], _0x6d0967['XxlLC'])) _0x16f281[_0x2259de(0x330)](_0x2b392e, this, function () {
                            const _0x2ce435 = _0x2259de,
                                _0xeabdec = new _0x5e7bc9(_0x2ce435(0x2ce)),
                                _0x15dd83 = new _0x362014(_0x16f281['LiPgX'], 'i'),
                                _0x500067 = _0x44ff43(_0x16f281[_0x2ce435(0x162)]);
                            !_0xeabdec[_0x2ce435(0x2a2)](_0x500067 + _0x2ce435(0x287)) || !_0x15dd83[_0x2ce435(0x2a2)](_0x16f281['tbloF'](_0x500067, _0x16f281[_0x2ce435(0x310)])) ? _0x500067('0') : _0x36a0d1();
                        })();
                        else return ![];
                    } ['constructor'](_0x2ec9f8[_0x75d4fd(0x1f5)](_0x2ec9f8['KiulO'], _0x2ec9f8[_0x75d4fd(0x225)]))[_0x75d4fd(0x320)](_0x2ec9f8[_0x75d4fd(0x292)]));
                    else {
                        if (_0x4eec01) return _0x575dd3;
                        else _0x2ec9f8[_0x75d4fd(0x2c1)](_0x39e98a, 0x0);
                    }
                }
            }
            _0x2ec9f8[_0x75d4fd(0x302)](_0x5d99b2, ++_0x62e36f);
        } else _0x2b1600[_0x75d4fd(0x264)](_0x6d0967[_0x75d4fd(0x32e)]('[PLUGIN ERROR] ', _0x34511f));
    }
    try {
        if (_0x44f6bc) return _0x5d99b2;
        else {
            if (_0x2ec9f8['UjTnp'](_0x2ec9f8[_0x5914e2(0x316)], _0x2ec9f8[_0x5914e2(0x27e)])) {
                const _0x317a10 = ['🌼', '❤️', '💐', '🔥', _0x5914e2(0x308), '❄️', '🧊', '🐳', '💥', '🥀', _0x5914e2(0x2ca), '🥹', '😩', '🫣', '🤭', '👻', '👾', '🫶', '😻', '🙌', '🫂', '🫀', _0x2ec9f8[_0x5914e2(0x205)], _0x5914e2(0x1cd), _0x5914e2(0x171), '🧑‍⚕️', '🧕', _0x2ec9f8[_0x5914e2(0x35f)], _0x2ec9f8[_0x5914e2(0x2b0)], _0x2ec9f8['lufTy'], _0x2ec9f8[_0x5914e2(0x191)], _0x2ec9f8[_0x5914e2(0x121)], '🧟', _0x2ec9f8[_0x5914e2(0x2d0)], '🧞', _0x2ec9f8[_0x5914e2(0x22d)], _0x2ec9f8['IuQWp'], _0x2ec9f8['vMToJ'], _0x2ec9f8[_0x5914e2(0x2cd)], _0x2ec9f8['kpENU'], '🤷', _0x2ec9f8['XVGOZ'], '🤦', _0x2ec9f8[_0x5914e2(0x203)], _0x2ec9f8[_0x5914e2(0x2c8)], '💇', '💃', _0x2ec9f8[_0x5914e2(0x21c)], '🚶', '🧶', '🧤', '👑', '💍', '👝', '💼', '🎒', '🥽', '🐻', '🐼', '🐭', '🐣', '🪿', '🦆', '🦊', '🦋', '🦄', '🪼', '🐋', '🐳', '🦈', '🐍', _0x2ec9f8[_0x5914e2(0x1b1)], '🦦', '🦚', '🌱', '🍃', '🎍', '🌿', '☘️', '🍀', '🍁', '🪺', '🍄', _0x5914e2(0x283), '🪸', '🪨', '🌺', '🪷', '🪻', '🥀', '🌹', '🌷', '💐', '🌾', '🌸', '🌼', '🌻', '🌝', '🌚', '🌕', '🌎', '💫', '🔥', '☃️', '❄️', _0x2ec9f8[_0x5914e2(0x37b)], '🫧', '🍟', '🍫', '🧃', '🧊', '🪀', '🤿', '🏆', '🥇', '🥈', '🥉', '🎗️', '🤹', _0x2ec9f8[_0x5914e2(0x31b)], '🎧', '🎤', '🥁', '🧩', '🎯', '🚀', '🚁', '🗿', _0x5914e2(0x212), '⌛', '⏳', '💸', '💎', '⚙️', '⛓️', '🔪', '🧸', '🎀', '🪄', '🎈', '🎁', '🎉', '🏮', '🪩', '📩', '💌', '📤', '📦', '📊', '📈', '📑', '📉', '📂', '🔖', '🧷', '📌', '📝', '🔏', '🔐', '🩷', '❤️', '🧡', '💛', '💚', '🩵', '💙', '💜', '🖤', '🩶', '🤍', '🤎', _0x5914e2(0x2ca), _0x2ec9f8[_0x5914e2(0x38f)], '💗', '💖', '💘', '💝', '❌', '✅', '🔰', '〽️', '🌐', '🌀', '⤴️', '⤵️', '🔴', '🟢', '🟡', '🟠', '🔵', '🟣', '⚫', '⚪', '🟤', '🔇', '🔊', '📢', '🔕', '♥️', '🕐', '🚩', _0x2ec9f8[_0x5914e2(0x36a)]],
                    _0x542f9d = _0x317a10[_0x35a34a['floor'](_0x2ec9f8['yEyQx'](_0x45e2ff['random'](), _0x317a10[_0x5914e2(0x1fc)]))];
                _0x56a511['react'](_0x542f9d);
            } else _0x5d99b2(0x0);
        }
    } catch (_0x237181) {}
}